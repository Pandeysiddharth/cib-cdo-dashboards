# Genie Space: CIB Account Opening Analytics

Configuration to apply in **Genie → New space → Configure**. Sections map 1:1 to the
Genie UI. Keep general instructions short; put logic in metric views and SQL expressions.

---

## 1. Data assets

Add in this order (Genie weights the first assets more heavily):

| Asset | Purpose | Notes |
|---|---|---|
| `mv_onboarding_kpis` | Case-level KPIs — volumes, TAT, FTR, SLA | Primary. Most questions resolve here. |
| `mv_task_kpis` | Queue / team / role KPIs, referral flows | For "where stuck", "which team", "backlog" |
| `v_case_summary` | Case-level drill-down and lists | For "show me the cases", "list breached cases" |

**Do not add** `acct_opening_raw`, `v_task_events`, or the `ref_*` tables. They add noise and
bypass the governed definitions. If a task-level listing is needed later, add `v_task_events`
with a note restricting its use to row listings.

Run `05_column_semantics.sql` first so `v_case_summary` carries column comments Genie can read.

## 2. Space settings

- **Title**: CIB Account Opening Analytics
- **Description**: Ask about account-opening case volumes, turnaround time (TAT), first time right (FTR), SLA breaches, referrals and queue backlog across markets, segments and client tiers.
- **Warehouse**: Serverless SQL (same one the dashboard uses)
- **Sample questions** (shown on the landing screen):
  1. How many cases were completed this month by booking location?
  2. What is our FTR rate by client tier this quarter?
  3. Which team has the highest referral rate?
  4. Show SLA breached cases for Singapore this week
  5. What is the average turnaround time trend by month this year?

## 3. General instructions

Paste exactly this. It describes the business, not SQL mechanics.

```
This space covers Standard Chartered CIB account-opening cases. A case is a client request
to open one or more accounts; it moves through workflow queues (roles) grouped into three
teams: Client Manager (front office, Request Initiator), CLM Ops (execution: Request
Processor/Checker, Core Banking, Cheque Book, Signatory makers and checkers) and Channels
(S2B digital channel activation).

Definitions:
- A case has one status: Completed (account opened), Pending (in flight) or Cancelled.
- Volumes count every case regardless of status.
- Turnaround time (TAT) is calendar hours from first task start to last task end, for
  Completed cases only. It includes weekends, holidays and time waiting on the client.
- First time right (FTR) means a Completed case with no referral back. A referral back is
  when a queue returns the case to an earlier queue with a reason recorded.
- SLA is same-day completion. Cases initiated before 16:00 market time are due that day;
  cases initiated at or after 16:00 are due the next calendar day. Cancelled cases and
  cases referred back to the Request Initiator are excluded from SLA measurement.
  "Received after cutoff" cases are NOT breaches; their due date simply rolls over.

Conventions:
- Use mv_onboarding_kpis for case-level KPIs and mv_task_kpis for team/role/queue questions.
  Use v_case_summary only when the user asks to list or see individual cases.
- Default geography is booking_location. Default time dimension is initiated_date.
- "Today", "this week", "this month" refer to initiated_date unless the user says otherwise.
- Report TAT in hours unless the value exceeds 48, then also show days.
- Express rates as percentages with one decimal.
- If asked about something not in the data (e.g. RM names, client names, revenue), say the
  data does not contain it rather than approximating.
```

## 4. SQL expressions (knowledge store)

Add each entry in `02_sql_expressions.sql` as a **SQL expression** of the type indicated
(filter / measure / dimension). These are the reusable building blocks Genie should prefer.

## 5. Example SQL queries

Add each pair in `03_example_queries.sql`. These teach query *shape* (MEASURE syntax, GROUP
BY on metric view dimensions, date filters). Pick the 8–10 that best match the real questions
Ketan sends back; more than ~15 dilutes retrieval.

## 6. Value dictionaries

After running validation query 3 from `../sql/05_validation.sql`, add the distinct values of
`case_stage`, `task_status`, `role`, `team`, `client_tier`, `segment` and `booking_location`
as value descriptions on `v_case_summary` and `mv_task_kpis`. This is the single highest-impact
accuracy step — it stops Genie guessing "SG" vs "Singapore" or "Platinum" vs "PLAT".

## 7. Benchmarks

Load `04_benchmarks.json` (question + expected SQL). Run before UAT and after every config
change. Target ≥ 90 % pass. When a benchmark fails:

1. Check the metric view first — missing synonym or ambiguous comment?
2. Then value dictionary — did Genie guess a literal?
3. Then SQL expression — is there a reusable filter it should have used?
4. Only then add an example query or instruction.

## 8. Access

- Space permission: **Can Run** for ops and management groups; **Can Edit** for the two
  named space owners.
- Row-level security is inherited from the Silver layer; do not duplicate in Genie.
- Enable **Genie in the dashboard** (companion space) and point it at this configured space
  rather than the auto-generated one.

## 9. Ownership

| Role | Owner |
|---|---|
| Space owner (config, benchmarks) | SCB CIB data lead — TBC with Ketan |
| Metric definitions | KPI owner on the business side |
| Weekly review | Review thumbs-down feedback and failed queries every Monday; re-run benchmarks |

-- =============================================================================
-- Genie knowledge store: Example SQL queries
-- Add each pair in Genie > Configure > Instructions > Example SQL queries.
-- These teach query SHAPE: MEASURE() on metric views, metric-view dimensions in
-- GROUP BY, date filters on initiated_date, when to fall back to v_case_summary.
-- =============================================================================

-- Q: How many cases did we receive this month by booking location?
SELECT booking_location,
       MEASURE(total_cases)     AS total_cases,
       MEASURE(completed_cases) AS completed,
       MEASURE(pending_cases)   AS pending,
       MEASURE(cancelled_cases) AS cancelled
FROM mv_onboarding_kpis
WHERE initiated_date >= date_trunc('MONTH', current_date())
GROUP BY booking_location
ORDER BY total_cases DESC;

-- Q: What is the monthly volume trend for the last 12 months?
SELECT initiated_month,
       MEASURE(total_cases)     AS total_cases,
       MEASURE(completed_cases) AS completed
FROM mv_onboarding_kpis
WHERE initiated_date >= add_months(date_trunc('MONTH', current_date()), -12)
GROUP BY initiated_month
ORDER BY initiated_month;

-- Q: What is the average turnaround time by client tier this quarter?
SELECT client_tier,
       MEASURE(avg_tat_hrs)    AS avg_tat_hrs,
       MEASURE(median_tat_hrs) AS median_tat_hrs,
       MEASURE(p90_tat_hrs)    AS p90_tat_hrs,
       MEASURE(completed_cases) AS completed_cases
FROM mv_onboarding_kpis
WHERE initiated_date >= date_trunc('QUARTER', current_date())
GROUP BY client_tier
ORDER BY avg_tat_hrs DESC;

-- Q: Which market has the longest turnaround time?
SELECT booking_location,
       MEASURE(avg_tat_hrs)     AS avg_tat_hrs,
       MEASURE(completed_cases) AS completed_cases
FROM mv_onboarding_kpis
GROUP BY booking_location
HAVING MEASURE(completed_cases) >= 10
ORDER BY avg_tat_hrs DESC
LIMIT 1;

-- Q: What is our FTR rate by segment this year?
SELECT segment,
       MEASURE(ftr_rate)        AS ftr_rate,
       MEASURE(ftr_cases)       AS ftr_cases,
       MEASURE(completed_cases) AS completed_cases
FROM mv_onboarding_kpis
WHERE initiated_date >= date_trunc('YEAR', current_date())
GROUP BY segment
ORDER BY ftr_rate DESC;

-- Q: How has FTR trended week over week this quarter?
SELECT initiated_week,
       MEASURE(ftr_rate)        AS ftr_rate,
       MEASURE(completed_cases) AS completed_cases
FROM mv_onboarding_kpis
WHERE initiated_date >= date_trunc('QUARTER', current_date())
GROUP BY initiated_week
ORDER BY initiated_week;

-- Q: What are the top reasons for referral back?
SELECT first_referral_reason,
       MEASURE(referred_cases) AS referred_cases
FROM mv_onboarding_kpis
WHERE first_referral_reason IS NOT NULL
GROUP BY first_referral_reason
ORDER BY referred_cases DESC
LIMIT 10;

-- Q: Which team sends cases back the most?
SELECT referred_from_team,
       MEASURE(referral_count)  AS referrals,
       MEASURE(distinct_cases)  AS cases_affected
FROM mv_task_kpis
WHERE is_referral = TRUE
GROUP BY referred_from_team
ORDER BY referrals DESC;

-- Q: Which team or role has the lowest first time right?
SELECT team, role,
       MEASURE(team_ftr_rate)      AS team_ftr_rate,
       MEASURE(cases_referred_back) AS cases_referred_back,
       MEASURE(distinct_cases)     AS cases_touched
FROM mv_task_kpis
GROUP BY team, role
ORDER BY team_ftr_rate ASC;

-- Q: Where are cases getting stuck? / Which queue has the biggest backlog?
SELECT team, role,
       MEASURE(open_tasks)            AS backlog,
       MEASURE(avg_task_duration_hrs) AS avg_handling_hrs,
       MEASURE(avg_handoff_wait_hrs)  AS avg_wait_before_hrs
FROM mv_task_kpis
GROUP BY team, role
ORDER BY backlog DESC;

-- Q: Which stage takes the longest?
SELECT role,
       MEASURE(avg_task_duration_hrs) AS avg_hrs,
       MEASURE(p90_task_duration_hrs) AS p90_hrs,
       MEASURE(task_count)            AS tasks
FROM mv_task_kpis
WHERE task_status = 'Closed'
GROUP BY role
ORDER BY avg_hrs DESC;

-- Q: What is the SLA breach rate by market this month?
SELECT booking_location,
       MEASURE(sla_breach_rate)    AS breach_rate,
       MEASURE(sla_breached_cases) AS breached,
       MEASURE(sla_eligible_cases) AS eligible
FROM mv_onboarding_kpis
WHERE initiated_date >= date_trunc('MONTH', current_date())
GROUP BY booking_location
ORDER BY breach_rate DESC;

-- Q: How many cases are at risk of breaching SLA today?
SELECT booking_location, last_team,
       MEASURE(sla_at_risk_cases) AS at_risk
FROM mv_onboarding_kpis
WHERE sla_due_date = current_date()
GROUP BY booking_location, last_team
HAVING MEASURE(sla_at_risk_cases) > 0
ORDER BY at_risk DESC;

-- Q: What share of cases arrive after the 4pm cutoff, by market?
SELECT booking_location,
       MEASURE(cases_received_after_cutoff) AS after_cutoff,
       MEASURE(total_cases)                 AS total_cases,
       MEASURE(cases_received_after_cutoff) / MEASURE(total_cases) AS after_cutoff_share
FROM mv_onboarding_kpis
GROUP BY booking_location
ORDER BY after_cutoff_share DESC;

-- Q: Show me the breached cases for Singapore this week
-- (listing individual cases -> use v_case_summary, not the metric view)
SELECT case_no, client_tier, segment, initiated_ts, sla_due_date,
       last_team, last_role, last_task_name, case_stage, sla_days_late
FROM v_case_summary
WHERE booking_location = 'Singapore'          -- confirm literal from value dictionary
  AND is_sla_breach = TRUE
  AND initiated_date >= date_trunc('WEEK', current_date())
ORDER BY sla_days_late DESC, initiated_ts;

-- Q: List pending cases older than 3 days with the team holding them
SELECT case_no, booking_location, client_tier, initiated_ts,
       round(case_age_hrs / 24, 1) AS age_days,
       last_team, last_role, last_task_name, referral_count
FROM v_case_summary
WHERE case_stage = 'Pending' AND case_age_hrs > 72
ORDER BY case_age_hrs DESC;

-- Q: How much slower are referred cases than straight-through cases?
-- (cross-cutting comparison not expressible as a single metric view measure -> v_case_summary)
SELECT AVG(case_tat_hrs)                                         AS avg_tat_all,
       AVG(CASE WHEN is_ftr THEN case_tat_hrs END)               AS avg_tat_ftr,
       AVG(CASE WHEN referral_count > 0 THEN case_tat_hrs END)   AS avg_tat_referred
FROM v_case_summary
WHERE case_stage = 'Completed';

-- Q: Compare this month's volumes and TAT against last month
SELECT initiated_month,
       MEASURE(total_cases)   AS total_cases,
       MEASURE(avg_tat_hrs)   AS avg_tat_hrs,
       MEASURE(ftr_rate)      AS ftr_rate,
       MEASURE(sla_breach_rate) AS breach_rate
FROM mv_onboarding_kpis
WHERE initiated_date >= date_trunc('MONTH', add_months(current_date(), -1))
GROUP BY initiated_month
ORDER BY initiated_month;

-- Q: How long do cases wait before someone picks them up, by market?
SELECT booking_location,
       MEASURE(avg_pickup_wait_hrs) AS avg_pickup_wait_hrs,
       MEASURE(total_cases)         AS total_cases
FROM mv_onboarding_kpis
GROUP BY booking_location
ORDER BY avg_pickup_wait_hrs DESC;

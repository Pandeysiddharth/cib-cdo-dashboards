-- =============================================================================
-- Column-level semantics on v_case_summary (Genie reads UC comments).
-- Metric views carry their own comments; this covers the drill-down view.
-- Run after ../sql/02_silver_views.sql.
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

-- identifiers
COMMENT ON COLUMN v_case_summary.case_no IS 'Unique case number. Use to list or look up individual cases.';
COMMENT ON COLUMN v_case_summary.master_number IS 'Reference grouping multiple related accounts or cases for one client.';
COMMENT ON COLUMN v_case_summary.relationship_number IS 'Client relationship identifier.';
COMMENT ON COLUMN v_case_summary.leid IS 'Legal entity identifier of the client.';

-- dimensions
COMMENT ON COLUMN v_case_summary.booking_location IS 'Market/country where the case was booked. DEFAULT geographic dimension. Values: see value dictionary.';
COMMENT ON COLUMN v_case_summary.country_of_account IS 'Country of the account being opened; may differ from booking_location.';
COMMENT ON COLUMN v_case_summary.branch_code IS 'Branch handling the case.';
COMMENT ON COLUMN v_case_summary.client_tier IS 'Client priority tier used by ops to sequence queues (e.g. Platinum > Gold > Silver). Platinum = highest priority.';
COMMENT ON COLUMN v_case_summary.segment IS 'Client business segment (e.g. Corporate, Financial Institution, Public Sector). NOT a product segment.';
COMMENT ON COLUMN v_case_summary.sub_segment IS 'Client sub-segment within segment.';
COMMENT ON COLUMN v_case_summary.product_code IS 'Product associated with the case.';
COMMENT ON COLUMN v_case_summary.account_type IS 'Type of account being opened.';
COMMENT ON COLUMN v_case_summary.case_type IS 'Case type. Future enhancement; may be sparsely populated — do not rely on it for completion status.';
COMMENT ON COLUMN v_case_summary.no_of_accounts IS 'Number of accounts opened under this case.';

-- status
COMMENT ON COLUMN v_case_summary.case_stage IS 'Case status: Completed (account opened), Pending (in flight), Cancelled. Synonyms: status, outcome.';
COMMENT ON COLUMN v_case_summary.is_completed IS 'TRUE when case_stage = Completed.';
COMMENT ON COLUMN v_case_summary.is_pending IS 'TRUE when case_stage = Pending (open / in-flight / WIP).';
COMMENT ON COLUMN v_case_summary.is_cancelled IS 'TRUE when case_stage = Cancelled.';
COMMENT ON COLUMN v_case_summary.last_team IS 'Team currently holding the case: Client Manager, CLM Ops or Channels.';
COMMENT ON COLUMN v_case_summary.last_role IS 'Workflow role (queue) currently holding the case, e.g. Core Banking Checker.';
COMMENT ON COLUMN v_case_summary.last_task_name IS 'Most recent task on the case.';
COMMENT ON COLUMN v_case_summary.last_task_status IS 'Open or Closed status of the most recent task.';
COMMENT ON COLUMN v_case_summary.task_count IS 'Number of task rows on the case (higher = more handoffs or referrals).';
COMMENT ON COLUMN v_case_summary.open_task_count IS 'Tasks still open on the case.';

-- timing (all market-local)
COMMENT ON COLUMN v_case_summary.initiated_ts IS 'When the case was submitted into the system (market-local). Drives SLA due date. NOT the TAT start.';
COMMENT ON COLUMN v_case_summary.initiated_date IS 'Date of initiated_ts. DEFAULT time dimension for all KPIs.';
COMMENT ON COLUMN v_case_summary.first_start_ts IS 'When the first task started. TAT clock starts here.';
COMMENT ON COLUMN v_case_summary.last_end_ts IS 'When the last task ended. TAT clock stops here for Completed cases.';
COMMENT ON COLUMN v_case_summary.pickup_wait_hrs IS 'Hours between initiated_ts and first_start_ts — time the case sat before anyone picked it up.';
COMMENT ON COLUMN v_case_summary.case_tat_hrs IS 'Turnaround time in CALENDAR hours (weekends, holidays, client wait included). Completed cases only; NULL otherwise.';
COMMENT ON COLUMN v_case_summary.case_age_hrs IS 'Hours since first task start for Pending cases; NULL otherwise. Use for ageing / stuck cases.';
COMMENT ON COLUMN v_case_summary.tat_bucket IS 'TAT band for Completed cases: 0-4h, 4-8h, 8-24h, 1-3d, 3-7d, >7d.';
COMMENT ON COLUMN v_case_summary.ageing_bucket IS 'Age band for Pending cases: 0-1d, 1-3d, 3-7d, >7d.';
COMMENT ON COLUMN v_case_summary.hrs_client_manager IS 'Active hours spent by Client Manager team tasks on this case.';
COMMENT ON COLUMN v_case_summary.hrs_clm_ops IS 'Active hours spent by CLM Ops (execution team) tasks on this case.';
COMMENT ON COLUMN v_case_summary.hrs_channels IS 'Active hours spent by Channels team tasks on this case.';
COMMENT ON COLUMN v_case_summary.hrs_handoff_wait IS 'Total hours the case waited between tasks (queue-to-queue handoffs).';

-- referrals / FTR
COMMENT ON COLUMN v_case_summary.referral_count IS 'Number of times the case was referred back to an earlier queue (rows with Reason populated). 0 = straight-through.';
COMMENT ON COLUMN v_case_summary.referral_count_client_manager IS 'Referrals landing on the Client Manager (Request Initiator) queue.';
COMMENT ON COLUMN v_case_summary.referral_count_clm_ops IS 'Referrals landing on CLM Ops queues.';
COMMENT ON COLUMN v_case_summary.referral_count_channels IS 'Referrals landing on Channels queues.';
COMMENT ON COLUMN v_case_summary.has_referral_to_initiator IS 'TRUE if the case was sent back to the Request Initiator (client manager) at least once. Such cases are excluded from SLA.';
COMMENT ON COLUMN v_case_summary.is_ftr IS 'First Time Right: TRUE when Completed with zero referrals. Synonyms: straight-through, STP, clean.';
COMMENT ON COLUMN v_case_summary.first_referral_reason IS 'Reason recorded on the first referral back; NULL for straight-through cases.';
COMMENT ON COLUMN v_case_summary.first_referral_sub_reason IS 'Sub-reason on the first referral back.';

-- SLA
COMMENT ON COLUMN v_case_summary.cutoff_local_time IS 'Market cutoff (HH:mm:ss). Cases initiated at/after this get next-day SLA. Currently 16:00 for all markets.';
COMMENT ON COLUMN v_case_summary.received_after_cutoff IS 'TRUE if initiated at/after cutoff. These are NOT breaches; the due date rolls to the next day.';
COMMENT ON COLUMN v_case_summary.sla_due_date IS 'Date by which the case must be Completed: initiated_date, or initiated_date + 1 if received after cutoff.';
COMMENT ON COLUMN v_case_summary.sla_eligible IS 'TRUE if measured against SLA: not Cancelled and never referred back to Request Initiator.';
COMMENT ON COLUMN v_case_summary.is_sla_breach IS 'TRUE if SLA-eligible and not Completed by sla_due_date. Synonyms: breached, overdue, late, missed SLA.';
COMMENT ON COLUMN v_case_summary.is_sla_met IS 'TRUE if SLA-eligible and Completed on or before sla_due_date.';
COMMENT ON COLUMN v_case_summary.is_sla_at_risk IS 'TRUE if SLA-eligible, Pending, and due today.';
COMMENT ON COLUMN v_case_summary.sla_days_late IS 'Calendar days past sla_due_date for breached cases; NULL otherwise.';

-- data quality
COMMENT ON COLUMN v_case_summary.has_rescued_data IS 'TRUE if any source row for this case had unparsed fields (_rescued_data). Data-quality flag only.';

-- Tags help Genie and Catalog Explorer users find the certified assets
ALTER VIEW mv_onboarding_kpis SET TAGS ('certified' = 'true', 'domain' = 'cib_account_opening', 'genie' = 'primary');
ALTER VIEW mv_task_kpis      SET TAGS ('certified' = 'true', 'domain' = 'cib_account_opening', 'genie' = 'secondary');
ALTER VIEW v_case_summary    SET TAGS ('certified' = 'true', 'domain' = 'cib_account_opening', 'genie' = 'drilldown');

-- =============================================================================
-- Genie knowledge store: SQL expressions
-- Add each block in Genie > Configure > Instructions > SQL expressions.
-- Format per entry:  type | name | when to use | expression
-- Table-qualified expressions target v_case_summary unless noted.
-- =============================================================================

-- ---------------------------------------------------------------- FILTERS ----

-- FILTER | Straight-through cases
-- Use when the user says: straight through, STP, first time right, no referral, clean cases
is_ftr = TRUE

-- FILTER | Referred cases
-- Use when the user says: referred, referred back, rework, returned, bounced, sent back
referral_count > 0

-- FILTER | Breached cases
-- Use when the user says: breached, SLA breach, overdue, missed SLA, late
is_sla_breach = TRUE

-- FILTER | At-risk cases
-- Use when the user says: at risk, due today, about to breach, nearing SLA
is_sla_at_risk = TRUE

-- FILTER | Open / in-flight cases
-- Use when the user says: open, pending, in flight, in progress, WIP, backlog, outstanding
case_stage = 'Pending'

-- FILTER | Completed cases
-- Use when the user says: completed, closed, done, accounts opened
case_stage = 'Completed'

-- FILTER | Cancelled cases
-- Use when the user says: cancelled, canceled, withdrawn, dropped
case_stage = 'Cancelled'

-- FILTER | Received after cutoff
-- Use when the user says: after 4pm, after cutoff, late receipt, rolled over, next-day SLA
received_after_cutoff = TRUE

-- FILTER | Sent back to client / document chase
-- Use when the user says: sent back to RM, back to client manager, document missing, chased client
has_referral_to_initiator = TRUE

-- FILTER | Priority clients
-- Use when the user says: priority clients, top tier, platinum
client_tier = 'Platinum'          -- confirm literal from value dictionary

-- FILTER | Today (by initiated date)
initiated_date = current_date()

-- FILTER | This week
initiated_date >= date_trunc('WEEK', current_date())

-- FILTER | This month
initiated_date >= date_trunc('MONTH', current_date())

-- FILTER | Month to date vs same period last month
-- Use for MTD comparisons
initiated_date BETWEEN date_trunc('MONTH', current_date()) AND current_date()
  OR initiated_date BETWEEN date_trunc('MONTH', add_months(current_date(), -1))
                        AND add_months(current_date(), -1)

-- FILTER | Last 30 days
initiated_date >= date_sub(current_date(), 30)

-- FILTER | Year to date
initiated_date >= date_trunc('YEAR', current_date())

-- FILTER | Ageing over 3 days   (v_case_summary / Pending)
-- Use when the user says: stuck, ageing, aged, older than, sitting
case_stage = 'Pending' AND case_age_hrs > 72

-- FILTER | Execution team only   (mv_task_kpis)
-- Use when the user says: ops team, execution team, CLM Ops, processing team
team = 'CLM Ops'

-- FILTER | Checker roles only   (mv_task_kpis)
-- Use when the user says: checkers, approvals, review stage
role LIKE '%Checker%'

-- FILTER | Maker roles only   (mv_task_kpis)
role LIKE '%Maker%'


-- --------------------------------------------------------------- MEASURES ----
-- (Prefer the metric view measures; these cover gaps the metric views don't.)

-- MEASURE | Percentage of cases received after cutoff
-- Use when: what share of cases come in after 4pm
COUNT_IF(received_after_cutoff) / NULLIF(COUNT(1), 0)

-- MEASURE | Average TAT for straight-through cases only
-- Use when: how fast are clean cases, STP turnaround
AVG(CASE WHEN is_ftr THEN case_tat_hrs END)

-- MEASURE | Average TAT for referred cases only
-- Use when: how much does a referral cost in time
AVG(CASE WHEN referral_count > 0 THEN case_tat_hrs END)

-- MEASURE | TAT penalty of referral (hours)
-- Use when: impact of referrals on TAT, how much slower are referred cases
AVG(CASE WHEN referral_count > 0 THEN case_tat_hrs END)
  - AVG(CASE WHEN is_ftr THEN case_tat_hrs END)

-- MEASURE | Share of pending cases older than 3 days
-- Use when: ageing backlog %, stale backlog
COUNT_IF(case_stage = 'Pending' AND case_age_hrs > 72)
  / NULLIF(COUNT_IF(case_stage = 'Pending'), 0)

-- MEASURE | Same-day completion rate (all Completed, ignoring SLA eligibility)
-- Use when: how many cases closed same day, raw same-day %
COUNT_IF(case_stage = 'Completed' AND date(last_end_ts) = initiated_date)
  / NULLIF(COUNT_IF(case_stage = 'Completed'), 0)

-- MEASURE | Cases per day (throughput)
-- Use when: daily run rate, throughput, cases per day
COUNT(1) / NULLIF(COUNT(DISTINCT initiated_date), 0)


-- ------------------------------------------------------------- DIMENSIONS ----

-- DIMENSION | Team bucket   (v_case_summary; alias of last_team)
-- Use when: which team has the case
last_team

-- DIMENSION | Initiated hour of day
-- Use when: what time of day do cases arrive, intraday pattern, before/after cutoff
hour(initiated_ts)

-- DIMENSION | Day of week
-- Use when: which weekday, Monday vs Friday
date_format(initiated_date, 'EEEE')

-- DIMENSION | Referral count band
-- Use when: cases referred once vs multiple times
CASE WHEN referral_count = 0 THEN '0'
     WHEN referral_count = 1 THEN '1'
     WHEN referral_count = 2 THEN '2'
     ELSE '3+' END

-- DIMENSION | SLA outcome
-- Use when: SLA status breakdown, met vs breached vs pending vs excluded
CASE WHEN NOT sla_eligible THEN 'Excluded'
     WHEN is_sla_breach   THEN 'Breached'
     WHEN is_sla_met      THEN 'Met'
     WHEN is_sla_at_risk  THEN 'At risk'
     ELSE 'Pending' END

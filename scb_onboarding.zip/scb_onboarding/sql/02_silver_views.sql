-- =============================================================================
-- 02_silver_views.sql
-- SCB CIB Account Opening — Silver layer (no pipeline; plain views over bronze)
-- Promote to MATERIALIZED VIEW with a schedule if query latency demands it.
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

-- -----------------------------------------------------------------------------
-- v_task_events : one row per task worked on a case (typed, deduped, enriched)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_task_events
COMMENT 'One row per task performed on an account-opening case. Typed timestamps (market-local), deduplicated on re-ingestion, enriched with team, sequence, duration and referral flags. Business rules: a referral back creates a new row on the receiving queue with Reason populated; Reason is NULL on non-referral rows.'
AS
WITH typed AS (
  SELECT
    trim(Case_no)                              AS case_no,
    parse_ts(Initiated_time)                   AS initiated_ts,
    parse_ts(Start_time)                       AS start_ts,
    parse_ts(End_time)                         AS end_ts,
    trim(Booking_Location)                     AS booking_location,
    trim(Location)                             AS location,
    trim(Country_of_account)                   AS country_of_account,
    trim(Branch_code)                          AS branch_code,
    trim(Client_tier)                          AS client_tier,
    trim(Segment)                              AS segment,
    trim(Sub_Segment)                          AS sub_segment,
    trim(Product_Code)                         AS product_code,
    trim(Account_type)                         AS account_type,
    trim(Case_type)                            AS case_type,
    trim(Task_name)                            AS task_name,
    trim(Role)                                 AS role,
    initcap(trim(Task_Status))                 AS task_status,     -- Open / Closed
    initcap(trim(Case_stage))                  AS case_stage,      -- Completed / Pending / Cancelled
    nullif(trim(Reason), '')                   AS reason,
    nullif(trim(Sub_Reason), '')               AS sub_reason,
    nullif(trim(Sub_Reason_Others), '')        AS sub_reason_others,
    trim(LEID)                                 AS leid,
    trim(Master_number)                        AS master_number,
    try_cast(No_of_Accounts AS INT)            AS no_of_accounts,
    trim(Cheque_book_required)                 AS cheque_book_required,   -- confirm exact column name (truncated in UI)
    trim(CCID)                                 AS ccid,
    trim(Reserve_Account)                      AS reserve_account,
    trim(Relationship_Number)                  AS relationship_number,
    trim(Last_Task_name)                       AS last_task_name_src,
    source_file_name,
    source_file_path,
    ingested_by,
    ingested_at_utc,
    _rescued_data IS NOT NULL                  AS has_rescued_data,
    ROW_NUMBER() OVER (
      PARTITION BY trim(Case_no), trim(Task_name), trim(Role), Start_time
      ORDER BY ingested_at_utc DESC
    )                                          AS dedupe_rn
  FROM acct_opening_raw
),
deduped AS (
  SELECT * EXCEPT (dedupe_rn) FROM typed WHERE dedupe_rn = 1
),
enriched AS (
  SELECT
    d.*,
    r.team,
    r.role_order,
    coalesce(r.sla_applicable, FALSE)                                   AS sla_applicable,
    ROW_NUMBER()  OVER w                                                AS task_seq,
    COUNT(1)      OVER (PARTITION BY d.case_no)                         AS case_task_count,
    LAG(d.role)   OVER w                                                AS prev_role,
    LAG(d.team)   OVER w                                                AS prev_team,
    LAG(d.end_ts) OVER w                                                AS prev_end_ts,
    date(d.initiated_ts)                                                AS initiated_date,
    date(d.start_ts)                                                    AS start_date,
    date(d.end_ts)                                                      AS end_date,
    (unix_timestamp(d.end_ts) - unix_timestamp(d.start_ts)) / 3600.0   AS task_duration_hrs,
    d.reason IS NOT NULL                                                AS is_referral,
    d.reason IS NOT NULL AND d.role = 'Request Initiator'               AS is_referral_to_initiator,
    d.end_ts IS NULL OR d.task_status = 'Open'                          AS is_open_task
  FROM deduped d
  LEFT JOIN ref_role_team r ON d.role = r.role
  WINDOW w AS (PARTITION BY d.case_no ORDER BY d.start_ts, d.end_ts)
)
SELECT
  e.*,
  -- queue-to-queue handoff wait (time between previous task end and this start)
  (unix_timestamp(e.start_ts) - unix_timestamp(e.prev_end_ts)) / 3600.0 AS handoff_wait_hrs,
  -- on a referral row, the role/team that sent the case back is the previous task's
  CASE WHEN e.is_referral THEN e.prev_role END                           AS referred_from_role,
  CASE WHEN e.is_referral THEN e.prev_team END                           AS referred_from_team
FROM enriched e;


-- -----------------------------------------------------------------------------
-- v_case_summary : one row per case with all KPI inputs
-- Rules (confirmed with business 22 Oct 2026):
--   Volumes  : all cases (Completed + Pending + Cancelled)
--   TAT      : Completed cases only; first task start -> last task end; calendar hours
--   FTR      : Completed with zero referrals (no Reason populated on any row)
--   SLA      : due date = initiated date if before 16:00 local, else next day;
--              breach if not Completed by end of due date; excused if referred
--              back to Request Initiator; Cancelled never breaches
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_case_summary
COMMENT 'One row per account-opening case. Source of truth for Volumes, TAT, FTR and SLA KPIs. Timestamps are market-local. TAT = first task start to last task end in calendar hours, Completed cases only. FTR = Completed with no referral. SLA due date is the initiated date if initiated before the market cutoff (16:00), otherwise the next calendar day.'
AS
WITH per_case AS (
  SELECT
    case_no,
    -- dimensions (constant per case; take from first task)
    min_by(booking_location,   task_seq) AS booking_location,
    min_by(location,           task_seq) AS location,
    min_by(country_of_account, task_seq) AS country_of_account,
    min_by(branch_code,        task_seq) AS branch_code,
    min_by(client_tier,        task_seq) AS client_tier,
    min_by(segment,            task_seq) AS segment,
    min_by(sub_segment,        task_seq) AS sub_segment,
    min_by(product_code,       task_seq) AS product_code,
    min_by(account_type,       task_seq) AS account_type,
    min_by(case_type,          task_seq) AS case_type,
    min_by(leid,               task_seq) AS leid,
    min_by(master_number,      task_seq) AS master_number,
    min_by(relationship_number,task_seq) AS relationship_number,
    max(no_of_accounts)                  AS no_of_accounts,
    -- lifecycle
    min(initiated_ts)                    AS initiated_ts,
    min(start_ts)                        AS first_start_ts,
    max(end_ts)                          AS last_end_ts,
    max_by(case_stage,  task_seq)        AS case_stage,
    max_by(task_name,   task_seq)        AS last_task_name,
    max_by(role,        task_seq)        AS last_role,
    max_by(team,        task_seq)        AS last_team,
    max_by(task_status, task_seq)        AS last_task_status,
    count(1)                             AS task_count,
    count_if(is_open_task)               AS open_task_count,
    -- referrals
    count_if(is_referral)                            AS referral_count,
    count_if(is_referral AND team = 'Client Manager') AS referral_count_client_manager,
    count_if(is_referral AND team = 'CLM Ops')        AS referral_count_clm_ops,
    count_if(is_referral AND team = 'Channels')       AS referral_count_channels,
    bool_or(is_referral_to_initiator)                AS has_referral_to_initiator,
    min_by(reason,     CASE WHEN is_referral THEN task_seq END) AS first_referral_reason,
    min_by(sub_reason, CASE WHEN is_referral THEN task_seq END) AS first_referral_sub_reason,
    -- time spent per team (sum of task durations)
    sum(CASE WHEN team = 'Client Manager' THEN task_duration_hrs END) AS hrs_client_manager,
    sum(CASE WHEN team = 'CLM Ops'        THEN task_duration_hrs END) AS hrs_clm_ops,
    sum(CASE WHEN team = 'Channels'       THEN task_duration_hrs END) AS hrs_channels,
    sum(handoff_wait_hrs)                                              AS hrs_handoff_wait,
    bool_or(has_rescued_data)            AS has_rescued_data
  FROM v_task_events
  GROUP BY case_no
),
derived AS (
  SELECT
    p.*,
    coalesce(c.cutoff_local_time, '16:00:00')                            AS cutoff_local_time,
    date(p.initiated_ts)                                                 AS initiated_date,
    p.case_stage = 'Completed'                                           AS is_completed,
    p.case_stage = 'Pending'                                             AS is_pending,
    p.case_stage = 'Cancelled'                                           AS is_cancelled,
    date_format(p.initiated_ts, 'HH:mm:ss') >= coalesce(c.cutoff_local_time, '16:00:00')
                                                                         AS received_after_cutoff,
    (unix_timestamp(p.first_start_ts) - unix_timestamp(p.initiated_ts)) / 3600.0
                                                                         AS pickup_wait_hrs,
    CASE WHEN p.case_stage = 'Completed'
         THEN (unix_timestamp(p.last_end_ts) - unix_timestamp(p.first_start_ts)) / 3600.0 END
                                                                         AS case_tat_hrs,
    CASE WHEN p.case_stage = 'Pending'
         THEN (unix_timestamp(current_timestamp()) - unix_timestamp(p.first_start_ts)) / 3600.0 END
                                                                         AS case_age_hrs,
    p.case_stage = 'Completed' AND p.referral_count = 0                  AS is_ftr
  FROM per_case p
  LEFT JOIN ref_market_cutoff c ON p.booking_location = c.booking_location
),
sla AS (
  SELECT
    d.*,
    CASE WHEN d.received_after_cutoff THEN date_add(d.initiated_date, 1) ELSE d.initiated_date END
                                                                         AS sla_due_date,
    NOT d.is_cancelled AND NOT d.has_referral_to_initiator               AS sla_eligible
  FROM derived d
)
SELECT
  s.*,
  s.sla_eligible AND (
       (s.is_completed AND date(s.last_end_ts) > s.sla_due_date)
    OR (s.is_pending   AND current_date()      > s.sla_due_date)
  )                                                                      AS is_sla_breach,
  s.sla_eligible AND s.is_completed AND date(s.last_end_ts) <= s.sla_due_date
                                                                         AS is_sla_met,
  s.sla_eligible AND s.is_pending AND s.sla_due_date = current_date()    AS is_sla_at_risk,
  CASE WHEN s.sla_eligible AND s.is_completed AND date(s.last_end_ts) > s.sla_due_date
         THEN datediff(date(s.last_end_ts), s.sla_due_date)
       WHEN s.sla_eligible AND s.is_pending AND current_date() > s.sla_due_date
         THEN datediff(current_date(), s.sla_due_date) END               AS sla_days_late,
  CASE WHEN s.case_tat_hrs IS NULL THEN NULL
       WHEN s.case_tat_hrs <= 4   THEN '0-4h'
       WHEN s.case_tat_hrs <= 8   THEN '4-8h'
       WHEN s.case_tat_hrs <= 24  THEN '8-24h'
       WHEN s.case_tat_hrs <= 72  THEN '1-3d'
       WHEN s.case_tat_hrs <= 168 THEN '3-7d'
       ELSE '>7d' END                                                    AS tat_bucket,
  CASE WHEN s.case_age_hrs IS NULL THEN NULL
       WHEN s.case_age_hrs <= 24  THEN '0-1d'
       WHEN s.case_age_hrs <= 72  THEN '1-3d'
       WHEN s.case_age_hrs <= 168 THEN '3-7d'
       ELSE '>7d' END                                                    AS ageing_bucket
FROM sla s;

-- Note: current_date()/current_timestamp() are evaluated in session timezone,
-- while source timestamps are market-local. Set the SQL warehouse timezone to
-- the dominant market, or add a Booking_Location -> timezone lookup and use
-- from_utc_timestamp(current_timestamp(), tz) if multi-market precision matters.

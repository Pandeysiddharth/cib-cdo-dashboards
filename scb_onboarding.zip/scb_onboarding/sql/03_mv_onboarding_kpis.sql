-- =============================================================================
-- 03_mv_onboarding_kpis.sql
-- Unity Catalog metric view: case-level KPIs (Volumes, TAT, FTR, SLA)
-- Query pattern:  SELECT booking_location, MEASURE(ftr_rate) FROM mv_onboarding_kpis GROUP BY 1
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

CREATE OR REPLACE VIEW mv_onboarding_kpis
WITH METRICS
LANGUAGE YAML
COMMENT 'Governed KPIs for CIB account opening: case volumes, turnaround time, first-time-right and SLA. One row per case. Use MEASURE() on measures and GROUP BY dimensions.'
AS $$
version: 1.1

comment: >
  Account-opening case KPIs for CIB. Volumes count every case regardless of status.
  TAT is calendar hours from first task start to last task end, Completed cases only.
  FTR is a Completed case with no referral back (no Reason populated on any task).
  SLA is same-day completion: due date is the initiated date if initiated before
  the 16:00 market cutoff, otherwise the next calendar day. Cancelled cases and cases
  referred back to the Request Initiator are excluded from the SLA population.

source: scb_cib.account_opening.v_case_summary

dimensions:
  # ---- time ----
  - name: initiated_date
    expr: initiated_date
    comment: Calendar date the case was submitted into the system (market-local)
    synonyms: [date, case date, submission date, received date, day]
  - name: initiated_week
    expr: date_trunc('WEEK', initiated_date)
    comment: Week (Monday start) the case was initiated
    synonyms: [week, weekly]
  - name: initiated_month
    expr: date_trunc('MONTH', initiated_date)
    comment: Month the case was initiated
    synonyms: [month, monthly]
  - name: initiated_quarter
    expr: date_trunc('QUARTER', initiated_date)
    comment: Quarter the case was initiated
    synonyms: [quarter, quarterly]
  - name: initiated_year
    expr: year(initiated_date)
    comment: Year the case was initiated
    synonyms: [year, yearly, annual]
  - name: sla_due_date
    expr: sla_due_date
    comment: Date by which the case must be Completed to meet SLA
    synonyms: [due date, sla date, deadline]

  # ---- geography ----
  - name: booking_location
    expr: booking_location
    comment: Market / country where the case was booked. Default geographic view.
    synonyms: [market, country, location, geography, region]
  - name: country_of_account
    expr: country_of_account
    comment: Country of the account being opened (may differ from booking location)
    synonyms: [account country]
  - name: branch_code
    expr: branch_code
    comment: Branch handling the case
    synonyms: [branch]

  # ---- client ----
  - name: client_tier
    expr: client_tier
    comment: Client priority tier (e.g. Platinum, Gold, Silver). Platinum is highest priority.
    synonyms: [tier, priority, client priority]
  - name: segment
    expr: segment
    comment: Client business segment (e.g. Corporate, Financial Institution, Public Sector)
    synonyms: [client segment, business segment]
  - name: sub_segment
    expr: sub_segment
    comment: Client sub-segment within the segment
    synonyms: [sub segment]
  - name: product_code
    expr: product_code
    comment: Product associated with the case
    synonyms: [product]
  - name: account_type
    expr: account_type
    comment: Type of account being opened
  - name: case_type
    expr: case_type
    comment: Type of case (future enhancement; may be sparsely populated)

  # ---- status ----
  - name: case_stage
    expr: case_stage
    comment: Case-level status - Completed, Pending or Cancelled
    synonyms: [status, case status, stage, outcome]
  - name: last_team
    expr: last_team
    comment: Team currently holding the case (or that completed it)
    synonyms: [current team, team, queue, with team]
  - name: last_role
    expr: last_role
    comment: Role currently holding the case (or that completed it)
    synonyms: [current role, role, current queue]
  - name: last_task_name
    expr: last_task_name
    comment: Most recent task on the case
    synonyms: [current task, last task]
  - name: tat_bucket
    expr: tat_bucket
    comment: Turnaround-time band for Completed cases (0-4h, 4-8h, 8-24h, 1-3d, 3-7d, >7d)
    synonyms: [tat band, tat range, duration bucket]
  - name: ageing_bucket
    expr: ageing_bucket
    comment: Age band for Pending cases since first task start (0-1d, 1-3d, 3-7d, >7d)
    synonyms: [ageing, age band, aging]
  - name: received_after_cutoff
    expr: received_after_cutoff
    comment: TRUE if initiated at/after the 16:00 cutoff, so SLA rolled to the next day
    synonyms: [after cutoff, late receipt, rolled over]
  - name: is_ftr
    expr: is_ftr
    comment: TRUE if Completed with no referral back
    synonyms: [first time right, straight through, stp, no referral]
  - name: is_sla_breach
    expr: is_sla_breach
    comment: TRUE if the case missed its SLA due date
    synonyms: [breached, sla breach, overdue, late, missed sla]
  - name: first_referral_reason
    expr: first_referral_reason
    comment: Reason given on the first referral back (NULL for FTR cases)
    synonyms: [referral reason, reason, reject reason, return reason]
  - name: first_referral_sub_reason
    expr: first_referral_sub_reason
    comment: Sub-reason on the first referral back
    synonyms: [sub reason]

measures:
  # ---- volumes ----
  - name: total_cases
    expr: COUNT(1)
    comment: Number of cases, all statuses
    synonyms: [cases, volume, volumes, case count, number of cases, how many cases]
  - name: completed_cases
    expr: COUNT_IF(is_completed)
    comment: Cases with status Completed (account opened)
    synonyms: [completed, closed cases, accounts opened, opened]
  - name: pending_cases
    expr: COUNT_IF(is_pending)
    comment: Cases still in flight
    synonyms: [pending, open cases, in flight, in progress, wip, backlog]
  - name: cancelled_cases
    expr: COUNT_IF(is_cancelled)
    comment: Cases cancelled before completion
    synonyms: [cancelled, canceled, withdrawn]
  - name: completion_rate
    expr: COUNT_IF(is_completed) / NULLIF(COUNT_IF(NOT is_pending), 0)
    comment: Completed as a share of all closed (Completed + Cancelled) cases
    synonyms: [completion ratio]
  - name: total_accounts
    expr: SUM(no_of_accounts)
    comment: Total accounts across cases (a case can open several accounts)
    synonyms: [accounts, number of accounts]
  - name: cases_received_after_cutoff
    expr: COUNT_IF(received_after_cutoff)
    comment: Cases initiated at/after the market cutoff (SLA rolled to next day)
    synonyms: [after cutoff cases, late receipts, rollover cases]

  # ---- turnaround time (Completed only) ----
  - name: avg_tat_hrs
    expr: AVG(case_tat_hrs)
    comment: Mean turnaround time in calendar hours, Completed cases only
    synonyms: [tat, turnaround time, turnaround, average tat, cycle time, time to open, processing time]
  - name: median_tat_hrs
    expr: MEDIAN(case_tat_hrs)
    comment: Median turnaround time in calendar hours, Completed cases only
    synonyms: [median tat, typical tat, p50 tat]
  - name: p90_tat_hrs
    expr: PERCENTILE_APPROX(case_tat_hrs, 0.9)
    comment: 90th percentile turnaround time in hours, Completed cases only
    synonyms: [p90 tat, tail tat, slowest 10 percent]
  - name: max_tat_hrs
    expr: MAX(case_tat_hrs)
    comment: Longest turnaround time in hours
    synonyms: [max tat, longest case, worst tat]
  - name: avg_tat_days
    expr: AVG(case_tat_hrs) / 24
    comment: Mean turnaround time in calendar days, Completed cases only
    synonyms: [tat days, turnaround days, days to open]
  - name: avg_pickup_wait_hrs
    expr: AVG(pickup_wait_hrs)
    comment: Mean hours between case submission and the first task starting
    synonyms: [pickup time, wait before start, queue wait, time to pick up]
  - name: avg_handoff_wait_hrs
    expr: AVG(hrs_handoff_wait)
    comment: Mean total hours a case sat between tasks (queue-to-queue handoffs)
    synonyms: [handoff wait, idle time, waiting time between tasks]
  - name: avg_hrs_client_manager
    expr: AVG(hrs_client_manager)
    comment: Mean active hours spent by the Client Manager team per case
    synonyms: [client manager time, front office time, initiator time]
  - name: avg_hrs_clm_ops
    expr: AVG(hrs_clm_ops)
    comment: Mean active hours spent by CLM Ops (execution team) per case
    synonyms: [clm ops time, execution time, ops time, processing team time]
  - name: avg_hrs_channels
    expr: AVG(hrs_channels)
    comment: Mean active hours spent by the Channels team per case
    synonyms: [channels time, s2b time]
  - name: avg_case_age_hrs
    expr: AVG(case_age_hrs)
    comment: Mean age in hours of Pending cases since first task start
    synonyms: [case age, ageing, backlog age, how old]

  # ---- first time right ----
  - name: ftr_cases
    expr: COUNT_IF(is_ftr)
    comment: Completed cases with zero referrals back
    synonyms: [ftr, first time right cases, straight through cases, stp cases]
  - name: ftr_rate
    expr: COUNT_IF(is_ftr) / NULLIF(COUNT_IF(is_completed), 0)
    comment: Share of Completed cases that were first time right
    synonyms: [ftr rate, ftr %, first time right rate, stp rate, straight through rate]
  - name: referred_cases
    expr: COUNT_IF(referral_count > 0)
    comment: Cases with at least one referral back
    synonyms: [referred, cases with referral, rework cases, returned cases]
  - name: referral_rate
    expr: COUNT_IF(referral_count > 0) / NULLIF(COUNT(1), 0)
    comment: Share of all cases with at least one referral back
    synonyms: [referral %, rework rate, return rate]
  - name: total_referrals
    expr: SUM(referral_count)
    comment: Total referral-back events across cases
    synonyms: [referrals, refer backs, number of referrals, rework count]
  - name: avg_referrals_per_case
    expr: SUM(referral_count) / NULLIF(COUNT(1), 0)
    comment: Mean referral-back events per case
    synonyms: [referrals per case]
  - name: referrals_to_client_manager
    expr: SUM(referral_count_client_manager)
    comment: Referral-back events landing on the Client Manager (Request Initiator) queue
    synonyms: [referrals to initiator, sent back to front office, client manager referrals]
  - name: referrals_to_clm_ops
    expr: SUM(referral_count_clm_ops)
    comment: Referral-back events landing on CLM Ops queues
    synonyms: [clm ops referrals, execution team referrals]
  - name: referrals_to_channels
    expr: SUM(referral_count_channels)
    comment: Referral-back events landing on Channels queues
    synonyms: [channels referrals]
  - name: cases_referred_to_initiator
    expr: COUNT_IF(has_referral_to_initiator)
    comment: Cases sent back to the Request Initiator at least once (excused from SLA)
    synonyms: [sent back to client manager, client referrals, document chases]

  # ---- SLA ----
  - name: sla_eligible_cases
    expr: COUNT_IF(sla_eligible)
    comment: Cases measured against SLA (excludes Cancelled and cases referred to Request Initiator)
    synonyms: [sla population, in sla scope, sla cases]
  - name: sla_breached_cases
    expr: COUNT_IF(is_sla_breach)
    comment: SLA-eligible cases not Completed by their due date
    synonyms: [breaches, breached, sla breaches, breached cases, overdue cases, missed sla, late cases]
  - name: sla_met_cases
    expr: COUNT_IF(is_sla_met)
    comment: SLA-eligible cases Completed on or before their due date
    synonyms: [sla met, within sla, on time, met sla]
  - name: sla_breach_rate
    expr: COUNT_IF(is_sla_breach) / NULLIF(COUNT_IF(sla_eligible), 0)
    comment: Breached as a share of SLA-eligible cases
    synonyms: [breach rate, breach %, sla breach %, breach percentage]
  - name: sla_compliance_rate
    expr: COUNT_IF(is_sla_met) / NULLIF(COUNT_IF(sla_eligible AND NOT is_pending), 0)
    comment: Met as a share of SLA-eligible cases that have closed
    synonyms: [sla compliance, sla %, sla attainment, on time rate, sla adherence]
  - name: sla_at_risk_cases
    expr: COUNT_IF(is_sla_at_risk)
    comment: Pending SLA-eligible cases due today
    synonyms: [at risk, due today, about to breach, at risk of breach]
  - name: avg_sla_days_late
    expr: AVG(sla_days_late)
    comment: Mean days past due for breached cases
    synonyms: [days late, how late, average delay]
$$;

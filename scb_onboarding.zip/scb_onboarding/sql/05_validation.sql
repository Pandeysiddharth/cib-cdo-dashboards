-- =============================================================================
-- 05_validation.sql — run after 01-04 to confirm rules against real data
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

-- 1. Timestamp parsing coverage (should be ~100%; if not, add formats to parse_ts)
SELECT
  count(1)                                        AS rows_total,
  count_if(parse_ts(Initiated_time) IS NULL)      AS initiated_unparsed,
  count_if(parse_ts(Start_time)     IS NULL)      AS start_unparsed,
  count_if(parse_ts(End_time)       IS NULL)      AS end_unparsed,
  count_if(_rescued_data IS NOT NULL)             AS rescued_rows
FROM acct_opening_raw;

-- 2. Unparsed samples (to extend parse_ts)
SELECT DISTINCT Initiated_time, Start_time, End_time
FROM acct_opening_raw
WHERE parse_ts(Initiated_time) IS NULL OR parse_ts(Start_time) IS NULL
LIMIT 20;

-- 3. Value dictionaries (paste into Genie value descriptions)
SELECT 'Case_stage'  AS col, Case_stage  AS val, count(1) n FROM acct_opening_raw GROUP BY 1,2
UNION ALL SELECT 'Task_Status', Task_Status, count(1) FROM acct_opening_raw GROUP BY 1,2
UNION ALL SELECT 'Role',        Role,        count(1) FROM acct_opening_raw GROUP BY 1,2
UNION ALL SELECT 'Client_tier', Client_tier, count(1) FROM acct_opening_raw GROUP BY 1,2
UNION ALL SELECT 'Segment',     Segment,     count(1) FROM acct_opening_raw GROUP BY 1,2
ORDER BY 1, 3 DESC;

-- 4. Roles not in ref_role_team (should return no rows)
SELECT DISTINCT r.Role
FROM acct_opening_raw r LEFT JOIN ref_role_team t ON trim(r.Role) = t.role
WHERE t.role IS NULL;

-- 5. Rule check: Reason should only appear on referral rows.
--    If Reason is populated on the FIRST task of a case, the "Reason = referral" rule is wrong.
SELECT count_if(task_seq = 1 AND reason IS NOT NULL) AS reason_on_first_task,
       count_if(reason IS NOT NULL)                   AS referral_rows,
       count(1)                                        AS all_rows
FROM v_task_events;

-- 6. Dedupe effect
SELECT (SELECT count(1) FROM acct_opening_raw) AS raw_rows,
       (SELECT count(1) FROM v_task_events)    AS deduped_rows;

-- 7. Case-level sanity: every case has exactly one row; stage distribution
SELECT case_stage, count(1) cases,
       round(avg(case_tat_hrs), 1) avg_tat_hrs,
       round(avg(CASE WHEN is_ftr THEN 1 ELSE 0 END), 3) ftr_share
FROM v_case_summary GROUP BY 1;

-- 8. Cases with negative durations or end before start (data quality)
SELECT case_no, task_name, role, start_ts, end_ts
FROM v_task_events WHERE task_duration_hrs < 0 LIMIT 20;

-- 9. Metric view smoke test
SELECT booking_location,
       MEASURE(total_cases)       AS total_cases,
       MEASURE(completed_cases)   AS completed,
       MEASURE(avg_tat_hrs)       AS avg_tat_hrs,
       MEASURE(ftr_rate)          AS ftr_rate,
       MEASURE(sla_breach_rate)   AS sla_breach_rate
FROM mv_onboarding_kpis
GROUP BY 1 ORDER BY 2 DESC;

SELECT team, role,
       MEASURE(open_tasks)              AS backlog,
       MEASURE(avg_task_duration_hrs)   AS avg_hrs,
       MEASURE(referral_count)          AS referrals,
       MEASURE(team_ftr_rate)           AS team_ftr
FROM mv_task_kpis
GROUP BY 1, 2 ORDER BY team, role;

-- 10. Validate against the known cases Ketan provides
-- SELECT case_no, case_stage, case_tat_hrs, referral_count, is_ftr, sla_due_date, is_sla_breach
-- FROM v_case_summary WHERE case_no IN ('<straight-through 1>', '<referred 1>', ...);

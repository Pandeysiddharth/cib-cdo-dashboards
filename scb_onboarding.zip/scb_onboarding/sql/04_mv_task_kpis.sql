-- =============================================================================
-- 04_mv_task_kpis.sql
-- Unity Catalog metric view: task / queue-level KPIs (where are cases stuck,
-- which team refers back, team-level FTR)
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

CREATE OR REPLACE VIEW mv_task_kpis
WITH METRICS
LANGUAGE YAML
COMMENT 'Task and queue-level KPIs for CIB account opening: task volumes, task turnaround by role/team, queue backlog, and referral-back flows between teams. One row per task. Use for "where are cases getting stuck" and team-level FTR questions; use mv_onboarding_kpis for case-level KPIs.'
AS $$
version: 1.1

comment: >
  One row per task worked on a case. A referral back appears as a new task row on the
  receiving queue with a Reason populated; referred_from_team is the team that sent it
  back. Task duration is calendar hours from task start to task end.

source: scb_cib.account_opening.v_task_events

dimensions:
  - name: start_date
    expr: start_date
    comment: Date the task started (market-local)
    synonyms: [date, task date, day]
  - name: start_week
    expr: date_trunc('WEEK', start_date)
    comment: Week the task started
    synonyms: [week]
  - name: start_month
    expr: date_trunc('MONTH', start_date)
    comment: Month the task started
    synonyms: [month]
  - name: team
    expr: team
    comment: Business team owning the role - Client Manager, CLM Ops or Channels
    synonyms: [queue, team name, department]
  - name: role
    expr: role
    comment: Workflow role performing the task (e.g. Request Initiator, Core Banking Maker)
    synonyms: [role name, maker, checker, processor, queue name]
  - name: role_order
    expr: role_order
    comment: Approximate process sequence of the role (1 = Request Initiator)
    synonyms: [step, stage order, sequence]
  - name: task_name
    expr: task_name
    comment: Name of the task performed
    synonyms: [task, activity, step name]
  - name: task_status
    expr: task_status
    comment: Open or Closed
    synonyms: [status]
  - name: case_stage
    expr: case_stage
    comment: Case status recorded on this task row - Completed, Pending, Cancelled
    synonyms: [case status]
  - name: is_referral
    expr: is_referral
    comment: TRUE if this task row was created by a referral back (Reason populated)
    synonyms: [referral, refer back, rework, returned]
  - name: referred_from_team
    expr: referred_from_team
    comment: Team that sent the case back (on referral rows only)
    synonyms: [sent back by, referring team, source team]
  - name: referred_from_role
    expr: referred_from_role
    comment: Role that sent the case back (on referral rows only)
    synonyms: [sent back by role, referring role]
  - name: reason
    expr: reason
    comment: Referral reason (only populated on referral rows)
    synonyms: [referral reason, reject reason, return reason, why referred]
  - name: sub_reason
    expr: sub_reason
    comment: Referral sub-reason
    synonyms: [sub reason, detailed reason]
  - name: booking_location
    expr: booking_location
    comment: Market where the case was booked
    synonyms: [market, country, location]
  - name: client_tier
    expr: client_tier
    comment: Client priority tier
    synonyms: [tier, priority]
  - name: segment
    expr: segment
    comment: Client business segment
    synonyms: [client segment]
  - name: sla_applicable
    expr: sla_applicable
    comment: TRUE if the team performing the task is measured against SLA
    synonyms: [in sla scope]

measures:
  - name: task_count
    expr: COUNT(1)
    comment: Number of task rows
    synonyms: [tasks, task volume, number of tasks, workload]
  - name: distinct_cases
    expr: COUNT(DISTINCT case_no)
    comment: Number of distinct cases touched
    synonyms: [cases, unique cases, cases handled]
  - name: open_tasks
    expr: COUNT_IF(is_open_task)
    comment: Tasks currently open (queue backlog)
    synonyms: [backlog, open, queue size, pending tasks, in queue, wip]
  - name: closed_tasks
    expr: COUNT_IF(NOT is_open_task)
    comment: Tasks completed
    synonyms: [closed, completed tasks, done]
  - name: avg_task_duration_hrs
    expr: AVG(task_duration_hrs)
    comment: Mean hours from task start to task end
    synonyms: [task tat, task turnaround, handling time, processing time per task, time in queue]
  - name: median_task_duration_hrs
    expr: MEDIAN(task_duration_hrs)
    comment: Median hours from task start to task end
    synonyms: [median task tat, typical handling time]
  - name: p90_task_duration_hrs
    expr: PERCENTILE_APPROX(task_duration_hrs, 0.9)
    comment: 90th percentile hours from task start to task end
    synonyms: [p90 task tat, slow tasks]
  - name: total_task_hrs
    expr: SUM(task_duration_hrs)
    comment: Total active hours across tasks
    synonyms: [total effort, total hours, effort]
  - name: avg_handoff_wait_hrs
    expr: AVG(handoff_wait_hrs)
    comment: Mean hours a case waited between the previous task ending and this task starting
    synonyms: [handoff time, wait time, idle time, queue wait, time between tasks]
  - name: referral_count
    expr: COUNT_IF(is_referral)
    comment: Task rows created by a referral back
    synonyms: [referrals, refer backs, rework, returns, number of referrals]
  - name: referral_rate
    expr: COUNT_IF(is_referral) / NULLIF(COUNT(1), 0)
    comment: Referral rows as a share of all task rows
    synonyms: [referral %, rework rate, return rate]
  - name: team_ftr_rate
    expr: 1 - (COUNT(DISTINCT CASE WHEN is_referral THEN case_no END) / NULLIF(COUNT(DISTINCT case_no), 0))
    comment: Team-level first time right - share of cases touched by this team/role that were never referred back to it
    synonyms: [team ftr, role ftr, ftr by team, team first time right, team stp]
  - name: cases_referred_back
    expr: COUNT(DISTINCT CASE WHEN is_referral THEN case_no END)
    comment: Distinct cases referred back to this team/role at least once
    synonyms: [cases with rework, cases returned]
$$;

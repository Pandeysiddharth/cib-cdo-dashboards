-- =============================================================================
-- 01_reference_tables.sql
-- SCB CIB Account Opening — reference data + helper function
-- Replace scb_cib.account_opening with the target catalog.schema before running.
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

-- -----------------------------------------------------------------------------
-- Timestamp parser. Source columns are STRING with unconfirmed format.
-- Add/reorder formats after profiling. Returns NULL if nothing matches.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION parse_ts(s STRING)
RETURNS TIMESTAMP
COMMENT 'Parses source timestamp strings in known formats; NULL if unparseable'
RETURN COALESCE(
  try_to_timestamp(s, 'yyyy-MM-dd HH:mm:ss'),
  try_to_timestamp(s, 'yyyy-MM-dd HH:mm'),
  try_to_timestamp(s, 'dd/MM/yyyy HH:mm:ss'),
  try_to_timestamp(s, 'dd/MM/yyyy HH:mm'),
  try_to_timestamp(s, 'dd-MM-yyyy HH:mm:ss'),
  try_to_timestamp(s, 'yyyy-MM-dd''T''HH:mm:ss'),
  try_cast(s AS TIMESTAMP)
);

-- -----------------------------------------------------------------------------
-- Role -> Team mapping (from Ketan Akre, 22 Oct 2026)
-- role_order gives the implicit process sequence for funnel views.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE TABLE ref_role_team (
  role            STRING  NOT NULL COMMENT 'Exact Role value as it appears in the source',
  team            STRING  NOT NULL COMMENT 'Business team: Client Manager, CLM Ops, Channels',
  role_order      INT     NOT NULL COMMENT 'Approximate process sequence of the role',
  sla_applicable  BOOLEAN NOT NULL COMMENT 'TRUE if the team is measured against the same-day SLA'
)
COMMENT 'Maps workflow roles to business teams for FTR drill-down and SLA scope';

INSERT OVERWRITE ref_role_team VALUES
  ('Request Initiator',     'Client Manager',  1, FALSE),
  ('Request Processor',     'CLM Ops',         2, TRUE),
  ('Request Checker',       'CLM Ops',         3, TRUE),
  ('Core Banking Maker',    'CLM Ops',         4, TRUE),
  ('Core Banking Checker',  'CLM Ops',         5, TRUE),
  ('Cheque Book Maker',     'CLM Ops',         6, TRUE),
  ('Cheque Book Checker',   'CLM Ops',         7, TRUE),
  ('Signatory Maker',       'CLM Ops',         8, TRUE),
  ('Signatory Checker',     'CLM Ops',         9, TRUE),
  ('S2B Channel Maker',     'Channels',       10, FALSE),  -- TBC with business
  ('S2B Channel Checker',   'Channels',       11, FALSE);  -- TBC with business

-- -----------------------------------------------------------------------------
-- Market cutoff. Business confirmed 16:00 for all markets today; kept as a
-- table so a market-specific change is a row edit, not a redeploy.
-- Seeded from the distinct Booking_Locations present in the raw table.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE TABLE ref_market_cutoff (
  booking_location   STRING NOT NULL COMMENT 'Booking_Location value as in source',
  cutoff_local_time  STRING NOT NULL COMMENT 'HH:mm:ss, market-local. Cases initiated at/after this roll to next-day SLA'
)
COMMENT 'Per-market SLA cutoff time (market-local)';

INSERT OVERWRITE ref_market_cutoff
SELECT DISTINCT Booking_Location, '16:00:00'
FROM acct_opening_raw
WHERE Booking_Location IS NOT NULL;

-- -----------------------------------------------------------------------------
-- Operational user entitlements for row-level security (populate from IAM/AD).
-- Global users are listed in the is_global flag; everyone else is filtered.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ref_user_entitlement (
  user_principal    STRING  NOT NULL COMMENT 'Workspace user or group name',
  booking_location  STRING           COMMENT 'Location the user may see; NULL if is_global',
  is_global         BOOLEAN NOT NULL DEFAULT FALSE
)
COMMENT 'Drives the row filter on v_task_events / v_case_summary';

-- Row filter function. Attach with:
--   ALTER VIEW v_case_summary SET ROW FILTER rf_booking_location ON (booking_location);
-- (Views in UC support row filters only via the underlying table on some DBR
--  versions — if not, apply the same predicate inside the view WHERE clause.)
CREATE OR REPLACE FUNCTION rf_booking_location(loc STRING)
RETURNS BOOLEAN
RETURN EXISTS (
  SELECT 1 FROM ref_user_entitlement e
  WHERE (e.is_global OR e.booking_location = loc)
    AND (e.user_principal = current_user() OR is_account_group_member(e.user_principal))
);

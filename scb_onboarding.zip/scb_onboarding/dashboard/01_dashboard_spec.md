# AI/BI Dashboard Spec — CIB Account Opening Control Tower

One AI/BI (Lakeview) dashboard, six pages, two audiences. Pages 1–2 serve management
(global users); pages 3–6 serve operations (row-filtered by booking location). If the
business prefers hard separation, publish pages 1–2 as a second dashboard from the same
datasets — nothing else changes.

Genie is embedded via the companion space, pointed at the configured
"CIB Account Opening Analytics" space (not the auto-generated one).

---

## Datasets

Metric views are added **directly as datasets** so dashboard filters re-aggregate correctly
(a filter on `client_tier` recomputes `ftr_rate` from the underlying cases instead of
averaging pre-computed rates).

| Dataset | Source | Used on |
|---|---|---|
| `kpi` | metric view `mv_onboarding_kpis` | Pages 1, 3, 4, 5 |
| `task` | metric view `mv_task_kpis` | Pages 2, 3, 4 |
| `cases` | SQL on `v_case_summary` — see `02_datasets.sql` | Page 6, drill-through tables |
| `funnel` | SQL on `v_task_events` — role sequence | Page 2 |
| `kpi_prev` | `mv_onboarding_kpis` shifted one period | Page 1 deltas |
| `reasons` | SQL on `v_task_events` — referral reason × team | Page 4 |

## Global filters (top of every page)

| Filter | Field | Default | Notes |
|---|---|---|---|
| Date range | `initiated_date` | Last 30 days | Date-range picker; drives every dataset |
| Booking location | `booking_location` | All | Multi-select; row filter still applies underneath |
| Client tier | `client_tier` | All | Multi-select |
| Segment | `segment` | All | Multi-select |
| Case status | `case_stage` | All | Single-select; hidden on pages 3 and 5 where status is fixed by the KPI |

---

## Page 1 — Executive Summary  *(management)*

Purpose: the four KPIs on one screen, with direction of travel.

| # | Widget | Type | Measure / dimension | Notes |
|---|---|---|---|---|
| 1.1 | Total cases | Counter | `total_cases` | Delta vs previous period from `kpi_prev` |
| 1.2 | Average TAT | Counter | `avg_tat_hrs` | Format: `0.0 h`; show `avg_tat_days` as secondary if > 48 h |
| 1.3 | FTR rate | Counter | `ftr_rate` | Format `0.0%`; green ≥ target, amber within 5 pts, red below (target TBC with business) |
| 1.4 | SLA breach rate | Counter | `sla_breach_rate` | Format `0.0%`; inverse colour scale |
| 1.5 | Case status mix | Donut | `completed_cases`, `pending_cases`, `cancelled_cases` | One ring, three segments |
| 1.6 | Volume trend | Combo | bar `total_cases`, line `completed_cases` by `initiated_week` | Switch to `initiated_month` when range > 90 days (parameter) |
| 1.7 | KPI trend | Line | `ftr_rate`, `sla_breach_rate` by `initiated_week` | Dual-axis off; both are percentages |
| 1.8 | Market scorecard | Table | by `booking_location`: `total_cases`, `avg_tat_hrs`, `ftr_rate`, `sla_breach_rate`, `pending_cases` | Conditional colour on the two rates; sort by `total_cases` desc |
| 1.9 | Volume by segment × tier | Heatmap | `total_cases` by `segment` (rows) × `client_tier` (cols) | |

Layout: row 1 = four counters (3 cols each); row 2 = 1.5 (3) + 1.6 (5) + 1.7 (4); row 3 = 1.8 (8) + 1.9 (4).

## Page 2 — Pipeline & Backlog  *(management + ops)*

Purpose: where cases are right now, and where they are piling up.

| # | Widget | Type | Measure / dimension | Notes |
|---|---|---|---|---|
| 2.1 | Pending cases | Counter | `pending_cases` (dataset `kpi`, `case_stage = Pending`) | |
| 2.2 | Pending > 3 days | Counter | `cases` dataset: `COUNT_IF(case_age_hrs > 72)` | Red if > 10% of 2.1 |
| 2.3 | At risk today | Counter | `sla_at_risk_cases` | |
| 2.4 | Received after cutoff (today) | Counter | `cases_received_after_cutoff` filtered to today | Informational — not a breach |
| 2.5 | Process funnel | Funnel / horizontal bar | `funnel` dataset: distinct cases that have reached each `role_order` | Shows drop-off and where volume sits |
| 2.6 | Backlog by queue | Bar (horizontal) | `task.open_tasks` by `team`, `role`; stacked by `team` | Sort desc |
| 2.7 | Ageing distribution | Bar | `kpi.pending_cases` by `ageing_bucket` | Ordered 0-1d → >7d |
| 2.8 | Current holder | Treemap | `kpi.pending_cases` by `last_team` → `last_role` | Click to filter page |
| 2.9 | Intraday arrivals | Bar | `cases` dataset: cases by `hour(initiated_ts)` | Vertical reference line at 16:00 |

Layout: row 1 = four counters; row 2 = 2.5 (6) + 2.6 (6); row 3 = 2.7 (4) + 2.8 (4) + 2.9 (4).

## Page 3 — Turnaround Time  *(ops)*

Purpose: how long it takes, and which stage consumes the time. Fixed to `case_stage = Completed`.

| # | Widget | Type | Measure / dimension | Notes |
|---|---|---|---|---|
| 3.1 | Avg / Median / P90 TAT | 3 counters | `avg_tat_hrs`, `median_tat_hrs`, `p90_tat_hrs` | |
| 3.2 | Avg pickup wait | Counter | `avg_pickup_wait_hrs` | Time before anyone starts |
| 3.3 | TAT distribution | Bar | `completed_cases` by `tat_bucket` | Ordered |
| 3.4 | TAT trend | Line + band | `median_tat_hrs`, `p90_tat_hrs` by `initiated_week` | Median solid, P90 dashed |
| 3.5 | TAT by market | Bar | `avg_tat_hrs` by `booking_location` | Sort desc; colour by `completed_cases` |
| 3.6 | TAT by tier × segment | Table | `avg_tat_hrs`, `median_tat_hrs`, `completed_cases` by `client_tier`, `segment` | |
| 3.7 | Where the hours go | Stacked bar (100%) | `avg_hrs_client_manager`, `avg_hrs_clm_ops`, `avg_hrs_channels`, `avg_handoff_wait_hrs` | One bar per `booking_location`; handoff wait in grey |
| 3.8 | Handling time by role | Bar | `task.avg_task_duration_hrs` by `role` (ordered by `role_order`) | Error bar = P90 |
| 3.9 | FTR vs referred TAT | Bar (grouped) | `cases` dataset: avg TAT for `is_ftr` vs `referral_count > 0` by `booking_location` | Quantifies the referral penalty |

Layout: row 1 = 3.1 (3×2) + 3.2 (2) + 3.3 (4); row 2 = 3.4 (6) + 3.5 (6); row 3 = 3.6 (4) + 3.7 (4) + 3.8 (4); row 4 = 3.9 (12).

## Page 4 — First Time Right  *(ops)*

Purpose: how often cases go straight through, who sends them back, and why.

| # | Widget | Type | Measure / dimension | Notes |
|---|---|---|---|---|
| 4.1 | FTR rate | Counter | `ftr_rate` | Target line TBC |
| 4.2 | Referred cases | Counter | `referred_cases` | |
| 4.3 | Avg referrals / referred case | Counter | `total_referrals / referred_cases` (custom calc) | |
| 4.4 | Sent back to client | Counter | `cases_referred_to_initiator` | Excused from SLA |
| 4.5 | FTR trend | Line | `ftr_rate` by `initiated_week` | |
| 4.6 | FTR by market | Bar | `ftr_rate` by `booking_location` | Sort asc (worst first) |
| 4.7 | FTR by tier | Bar | `ftr_rate` by `client_tier` | |
| 4.8 | Team FTR | Bar | `task.team_ftr_rate` by `team`, `role` | Ordered by `role_order` |
| 4.9 | Referral flow | Sankey (or matrix table) | `reasons` dataset: `referred_from_team` → `team` (receiving), weight = referrals | Sankey if available in the workspace; otherwise heatmap table |
| 4.10 | Top referral reasons | Bar (horizontal) | `reasons` dataset: referrals by `reason` | Top 10; click filters 4.11 |
| 4.11 | Sub-reason breakdown | Table | `reason`, `sub_reason`, referrals, share | |

Layout: row 1 = four counters; row 2 = 4.5 (6) + 4.6 (3) + 4.7 (3); row 3 = 4.8 (5) + 4.9 (7); row 4 = 4.10 (6) + 4.11 (6).

## Page 5 — SLA  *(ops)*

Purpose: breaches, compliance and what's due today. Excludes Cancelled by definition.

| # | Widget | Type | Measure / dimension | Notes |
|---|---|---|---|---|
| 5.1 | SLA compliance | Counter | `sla_compliance_rate` | |
| 5.2 | Breached | Counter | `sla_breached_cases` | |
| 5.3 | At risk today | Counter | `sla_at_risk_cases` | |
| 5.4 | Avg days late | Counter | `avg_sla_days_late` | |
| 5.5 | SLA outcome mix | Stacked bar (100%) | `cases` dataset: Met / Breached / At risk / Pending / Excluded by `booking_location` | Uses the SLA outcome expression |
| 5.6 | Breach trend | Line | `sla_breach_rate` by `initiated_week`; secondary `cases_received_after_cutoff` | Shows whether rollovers correlate with breaches |
| 5.7 | Breaches by tier × market | Heatmap | `sla_breached_cases` by `client_tier` × `booking_location` | |
| 5.8 | Where breached cases are stuck | Bar | `kpi.sla_breached_cases` by `last_role` | Filter `is_sla_breach = TRUE`; ordered by `role_order` |
| 5.9 | Due today list | Table | `cases` dataset filtered `is_sla_at_risk`: `case_no`, `booking_location`, `client_tier`, `initiated_ts`, `last_role`, `last_task_name`, hours left | Sort by `initiated_ts`; Platinum rows highlighted |
| 5.10 | Breached list | Table | `cases` dataset filtered `is_sla_breach`: + `sla_due_date`, `sla_days_late`, `case_stage` | Sort by `sla_days_late` desc |

Layout: row 1 = four counters; row 2 = 5.5 (6) + 5.6 (6); row 3 = 5.7 (6) + 5.8 (6); row 4 = 5.9 (6) + 5.10 (6).

## Page 6 — Case Explorer  *(ops)*

Purpose: find a case and see its full journey. Also the Genie landing page.

| # | Widget | Type | Notes |
|---|---|---|---|
| 6.1 | Case search | Text parameter → filter `case_no` | Also filters by `relationship_number`, `master_number` |
| 6.2 | Case list | Table | `cases` dataset, all columns relevant to ops; status, FTR and SLA flags as coloured chips |
| 6.3 | Case journey | Table (or Gantt if available) | `v_task_events` for the selected `case_no`: `task_seq`, `role`, `team`, `task_name`, `start_ts`, `end_ts`, `task_duration_hrs`, `handoff_wait_hrs`, `is_referral`, `reason`, `referred_from_role` |
| 6.4 | Genie | Embedded Genie panel | "Ask about this data" — companion space |

Layout: row 1 = 6.1 (12); row 2 = 6.2 (12); row 3 = 6.3 (8) + 6.4 (4).

---

## Formatting & conventions

- Hours: `0.0 h`. Days: `0.0 d`. Rates: `0.0%`. Counts: `#,##0`.
- Colour: status fixed — Completed green, Pending amber, Cancelled grey, Breached red, At risk orange, FTR teal.
- Every page title states the status scope (e.g. "Turnaround Time — Completed cases").
- Counters carry the KPI definition in their description tooltip, copied from the metric view comment so dashboard and Genie say the same thing.
- Reference lines: 16:00 cutoff on intraday charts; FTR and SLA targets once the business confirms them.

## Row-level security

Inherited from the Silver layer (`rf_booking_location`). Publish with **embedded credentials off** so each viewer queries as themselves; global users see everything, operational users see their markets only. The booking-location filter remains visible but can only narrow what RLS already allows.

## Refresh

Datasets query live views; no schedule needed. If `v_case_summary` is promoted to a materialized view, align the dashboard's "last updated" stamp (`MAX(ingested_at_utc)` from `cases` dataset, shown as a small text widget on page 1) with the MV schedule.

## Open items before build

1. FTR and SLA compliance targets (for colour thresholds and reference lines).
2. Whether to split pages 1–2 into a separate management dashboard.
3. Confirm Sankey and Gantt availability in the workspace's dashboard version; fall back to matrix/table otherwise.
4. Real values for `booking_location` and `client_tier` for default sort orders and the Platinum highlight.

-- =============================================================================
-- Dashboard SQL datasets (those not served directly by a metric view)
-- Parameter syntax follows AI/BI dashboards: :param_name
-- Define parameters: date_from (DATE), date_to (DATE), case_no (STRING, optional)
-- =============================================================================

USE CATALOG scb_cib;
USE SCHEMA account_opening;

-- ----------------------------------------------------------------- cases ----
-- Case-level rows for tables, SLA lists, FTR-vs-referred TAT, intraday arrivals.
-- Keep every column the ops team may want to filter on; dashboard filters bind here.
SELECT
  case_no,
  relationship_number,
  master_number,
  booking_location,
  country_of_account,
  branch_code,
  client_tier,
  segment,
  sub_segment,
  product_code,
  account_type,
  no_of_accounts,
  case_stage,
  last_team,
  last_role,
  last_task_name,
  last_task_status,
  task_count,
  initiated_ts,
  initiated_date,
  hour(initiated_ts)                                     AS initiated_hour,
  date_format(initiated_date, 'EEEE')                    AS initiated_dow,
  first_start_ts,
  last_end_ts,
  pickup_wait_hrs,
  case_tat_hrs,
  case_tat_hrs / 24                                      AS case_tat_days,
  case_age_hrs,
  case_age_hrs / 24                                      AS case_age_days,
  tat_bucket,
  ageing_bucket,
  referral_count,
  CASE WHEN referral_count = 0 THEN '0'
       WHEN referral_count = 1 THEN '1'
       WHEN referral_count = 2 THEN '2'
       ELSE '3+' END                                     AS referral_band,
  is_ftr,
  CASE WHEN is_ftr THEN 'Straight-through'
       WHEN referral_count > 0 THEN 'Referred'
       ELSE 'Not completed' END                          AS ftr_label,
  has_referral_to_initiator,
  first_referral_reason,
  first_referral_sub_reason,
  received_after_cutoff,
  sla_due_date,
  sla_eligible,
  is_sla_breach,
  is_sla_met,
  is_sla_at_risk,
  sla_days_late,
  CASE WHEN NOT sla_eligible THEN 'Excluded'
       WHEN is_sla_breach   THEN 'Breached'
       WHEN is_sla_met      THEN 'Met'
       WHEN is_sla_at_risk  THEN 'At risk'
       ELSE 'Pending' END                                AS sla_outcome,
  -- hours remaining until end of due date (for the "due today" list)
  CASE WHEN is_sla_at_risk
       THEN (unix_timestamp(timestamp(date_add(sla_due_date, 1))) - unix_timestamp(current_timestamp())) / 3600.0
  END                                                    AS hrs_to_due,
  has_rescued_data
FROM v_case_summary
WHERE initiated_date BETWEEN :date_from AND :date_to;


-- ---------------------------------------------------------------- funnel ----
-- Distinct cases that have reached each role, in process order (page 2.5).
SELECT
  r.role_order,
  r.role,
  r.team,
  COUNT(DISTINCT t.case_no)                                      AS cases_reached,
  COUNT(DISTINCT CASE WHEN t.is_open_task THEN t.case_no END)    AS cases_currently_here,
  COUNT(DISTINCT CASE WHEN t.is_referral  THEN t.case_no END)    AS cases_referred_here
FROM ref_role_team r
LEFT JOIN v_task_events t
  ON t.role = r.role
 AND t.initiated_date BETWEEN :date_from AND :date_to
GROUP BY r.role_order, r.role, r.team
ORDER BY r.role_order;


-- ------------------------------------------------------------- kpi_prev -----
-- Same KPIs for the immediately preceding period of equal length (page 1 deltas).
SELECT
  MEASURE(total_cases)      AS total_cases_prev,
  MEASURE(avg_tat_hrs)      AS avg_tat_hrs_prev,
  MEASURE(ftr_rate)         AS ftr_rate_prev,
  MEASURE(sla_breach_rate)  AS sla_breach_rate_prev,
  MEASURE(pending_cases)    AS pending_cases_prev
FROM mv_onboarding_kpis
WHERE initiated_date BETWEEN date_sub(:date_from, datediff(:date_to, :date_from) + 1)
                         AND date_sub(:date_from, 1);


-- --------------------------------------------------------------- reasons ----
-- Referral events with sending and receiving team/role and reason (page 4.9–4.11).
SELECT
  initiated_date,
  booking_location,
  client_tier,
  segment,
  referred_from_team,
  referred_from_role,
  team                      AS received_by_team,
  role                      AS received_by_role,
  reason,
  sub_reason,
  sub_reason_others,
  COUNT(1)                  AS referrals,
  COUNT(DISTINCT case_no)   AS cases
FROM v_task_events
WHERE is_referral
  AND initiated_date BETWEEN :date_from AND :date_to
GROUP BY ALL;


-- -------------------------------------------------------------- journey -----
-- Full task history for one case (page 6.3). Bound to the case_no parameter.
SELECT
  task_seq,
  team,
  role,
  task_name,
  task_status,
  case_stage,
  start_ts,
  end_ts,
  round(task_duration_hrs, 2)   AS task_hrs,
  round(handoff_wait_hrs, 2)    AS wait_before_hrs,
  is_referral,
  referred_from_role,
  reason,
  sub_reason,
  sub_reason_others
FROM v_task_events
WHERE case_no = :case_no
ORDER BY task_seq;


-- ---------------------------------------------------------- last_updated ----
-- Freshness stamp (page 1 text widget).
SELECT MAX(ingested_at_utc) AS last_ingested_utc,
       COUNT(DISTINCT source_file_name) AS files_loaded
FROM v_task_events;

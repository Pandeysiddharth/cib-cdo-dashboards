import html, subprocess

CSS = """
@page { size: A4; margin: 0; }
body { font-family: 'Carlito', 'DejaVu Sans', sans-serif; font-size: 13pt; color: #1f2933; margin: 0; }
.page { page-break-after: always; }
.page:last-child { page-break-after: auto; }
h1 { font-size: 30pt; margin: 0 0 6px 0; color: #0b3c5d; letter-spacing: -0.3px; }
h2 { font-size: 21pt; margin: 0 0 4px 0; color: #0b3c5d; }
h3 { font-size: 15pt; margin: 20px 0 8px 0; color: #0b3c5d; page-break-after: avoid; }
p { margin: 4px 0 8px 0; line-height: 1.4; }
small, .muted { color: #6b7a86; }
.kicker { font-size: 10.5pt; letter-spacing: 2px; text-transform: uppercase; color: #e8731a; font-weight: bold; margin-bottom: 4px; }
.subtitle { font-size: 14pt; color: #52606d; margin-bottom: 18px; }
.rule { border-top: 3px solid #e8731a; width: 60px; margin: 10px 0 18px 0; }

/* step header */
.stephead.brk { page-break-before: always; }
.stephead { background: #0b3c5d; color: #fff; padding: 12px 16px; margin: 0 0 14px 0; }
.stephead .num { font-size: 10.5pt; letter-spacing: 2px; text-transform: uppercase; color: #ffb27a; }
.stephead .title { font-size: 19pt; font-weight: bold; }
.stephead .goal { font-size: 12pt; color: #d9e6f2; margin-top: 3px; }

/* sub step */
.sub { margin: 16px 0 4px 0; page-break-after: avoid; }
.sub .label { display: inline-block; font-weight: bold; font-size: 14pt; color: #1f2933; }
.badge { display: inline-block; font-size: 9.5pt; font-weight: bold; letter-spacing: 1px; padding: 2px 7px; margin-left: 8px; vertical-align: middle; border-radius: 3px; }
.badge.ui { background: #e3eef7; color: #0b3c5d; }
.badge.gc { background: #fde8d7; color: #b7501a; }
.badge.biz { background: #e6f4ea; color: #1e6b3a; }

/* boxes */
.box { margin: 8px 0 10px 0; border-left: 4px solid #ccc; padding: 8px 12px 9px 12px; page-break-inside: avoid; }
.box .head { font-size: 10pt; font-weight: bold; letter-spacing: 1.2px; text-transform: uppercase; margin-bottom: 5px; }
.prompt { border-left-color: #e8731a; background: #fff7f1; }
.prompt .head { color: #b7501a; }
.prompt .body { font-family: 'DejaVu Sans Mono', monospace; font-size: 10.5pt; line-height: 1.45; color: #2b2b2b; white-space: pre-wrap; }
.ui { border-left-color: #0b3c5d; background: #f1f6fb; }
.ui .head { color: #0b3c5d; }
.expect { border-left-color: #2e9e5b; background: #f0faf3; }
.expect .head { color: #1e6b3a; }
.warn { border-left-color: #d9a400; background: #fffbe8; }
.warn .head { color: #8a6a00; }
.stop { border-left-color: #c62828; background: #fdf0f0; }
.stop .head { color: #a31b1b; }
ol, ul { margin: 4px 0 6px 0; padding-left: 20px; line-height: 1.45; }
li { margin-bottom: 2px; }
code { font-family: 'DejaVu Sans Mono', monospace; font-size: 10.5pt; background: #eef1f4; padding: 0 3px; }

/* tables */
table.t { border-collapse: collapse; width: 100%; margin: 6px 0 12px 0; font-size: 11.5pt; page-break-inside: avoid; }
table.t th { background: #0b3c5d; color: #fff; text-align: left; padding: 6px 8px; font-weight: bold; }
table.t td { border-bottom: 1px solid #dde3e8; padding: 5px 8px; vertical-align: top; }
table.t tr:nth-child(even) td { background: #f7f9fb; }
table.t td.c { text-align: center; }
.fill { color: #aab4be; }

/* roadmap */
table.road { border-collapse: separate; border-spacing: 6px 0; width: 100%; margin: 14px 0; }
table.road td { vertical-align: top; width: 11%; }
.rcard { border-top: 5px solid #e8731a; background: #f7f9fb; padding: 8px 8px 10px 8px; height: 150px; }
.rcard .n { font-size: 24pt; font-weight: bold; color: #0b3c5d; line-height: 1; }
.rcard .t { font-weight: bold; font-size: 11.5pt; margin: 4px 0 4px 0; }
.rcard .d { font-size: 10pt; color: #52606d; line-height: 1.35; }
.rcard .time { font-size: 9.5pt; color: #e8731a; font-weight: bold; margin-top: 6px; }

/* legend */
table.legend { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
table.legend td { vertical-align: top; }
.footer-note { font-size: 10.5pt; color: #6b7a86; border-top: 1px solid #dde3e8; padding-top: 8px; margin-top: 20px; }
.cover { background: #0b3c5d; color: #fff; padding: 30mm 22mm 30mm 22mm; height: 205mm; page-break-after: always; }
.cover h1 { color: #fff; font-size: 40pt; }
.cover .subtitle { color: #d9e6f2; font-size: 16pt; }
.cover .meta { margin-top: 40mm; font-size: 12.5pt; color: #d9e6f2; line-height: 1.6; }
.cover .rule { border-color: #e8731a; }
.pill { display: inline-block; background: #e8731a; color: #fff; font-size: 11pt; font-weight: bold; padding: 3px 10px; border-radius: 12px; margin-right: 6px; }
"""

out = []
def raw(s): out.append(s)
def esc(s): return html.escape(s)

def page_start(): pass
def page_end(): pass

def stephead(num, title, goal, brk=True):
    raw(f'<div class="stephead{" brk" if brk else ""}"><div class="num">{esc(num)}</div><div class="title">{esc(title)}</div><div class="goal">{esc(goal)}</div></div>')

def sub(label, kind):
    badge = {'ui': 'UI', 'gc': 'Genie Code prompt', 'biz': 'Business sign-off'}[kind]
    raw(f'<div class="sub"><span class="label">{esc(label)}</span><span class="badge {kind}">{badge}</span></div>')

def prompt(text, head="Prompt — paste into Genie Code"):
    raw(f'<div class="box prompt"><div class="head">{esc(head)}</div><div class="body">{esc(text.strip())}</div></div>')

def ui(items, head="Where to click"):
    raw(f'<div class="box ui"><div class="head">{esc(head)}</div><ol>' + ''.join(f'<li>{i}</li>' for i in items) + '</ol></div>')

def expect(text, head="What you should see"):
    raw(f'<div class="box expect"><div class="head">{esc(head)}</div><p style="margin:0">{text}</p></div>')

def warn(text, head="If it doesn't look right"):
    raw(f'<div class="box warn"><div class="head">{esc(head)}</div><p style="margin:0">{text}</p></div>')

def stop(text, head="Stop here if"):
    raw(f'<div class="box stop"><div class="head">{esc(head)}</div><p style="margin:0">{text}</p></div>')

def p(text): raw(f'<p>{text}</p>')
def h3(text): raw(f'<h3>{esc(text)}</h3>')

def table(headers, rows, widths=None):
    raw('<table class="t"><tr>' + ''.join(
        f'<th{(" style=\"width:%s\"" % widths[i]) if widths else ""}>{h}</th>' for i, h in enumerate(headers)) + '</tr>')
    for r in rows:
        raw('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>')
    raw('</table>')

# ============================================================ COVER
raw('<div class="cover">')
raw('<div class="kicker" style="color:#ffb27a">Standard Chartered · CIB · Databricks</div>')
raw('<h1>Account Opening<br>Control Tower</h1>')
raw('<div class="rule"></div>')
raw('<div class="subtitle">Step-by-step implementation guide<br>Metric views · Genie natural-language analytics · AI/BI dashboard</div>')
raw('<div class="meta">')
raw('<span class="pill">No SQL required</span><span class="pill">Genie Code + UI</span><span class="pill">~4 hours hands-on</span>')
raw('<p style="margin-top:28px">Every step in this guide is either a click path in the Databricks UI or a prompt you paste into Genie Code, the AI assistant built into Databricks. You read what it produces, check it against the green box, and move on.</p>')
raw('<p>Prepared by Databricks Solutions Architecture · October 2026 · v1.0</p>')
raw('</div></div>')

# ============================================================ HOW TO READ
page_start()
raw('<div class="kicker">Before you begin</div><h2>How to read this guide</h2><div class="rule"></div>')
p('Each step has a dark header saying what you are building and why. Under it, numbered sub-steps are tagged with one of three badges:')
raw('<table class="legend">')
raw('<tr><td style="width:230px"><span class="badge ui">UI</span></td><td>Click through the Databricks interface. The blue box tells you exactly where.</td></tr>')
raw('<tr><td><span class="badge gc">Genie Code prompt</span></td><td>Copy the text in the orange box and paste it into Genie Code (the sparkle icon on the right edge of the screen, or <code>Cmd/Ctrl + I</code>). Replace anything in <code>&lt;angle brackets&gt;</code> with your own values from Step 0.3.</td></tr>')
raw('<tr><td><span class="badge biz">Business sign-off</span></td><td>Pause and get the business owner to confirm before continuing.</td></tr>')
raw('</table>')
raw('<table class="legend">')
raw('<tr><td style="width:230px"><div class="box expect" style="margin:0"><div class="head">What you should see</div></div></td><td>The expected result. If you see this, continue.</td></tr>')
raw('<tr><td><div class="box warn" style="margin:0"><div class="head">If it doesn\'t look right</div></div></td><td>A fix, usually another prompt.</td></tr>')
raw('<tr><td><div class="box stop" style="margin:0"><div class="head">Stop here if</div></div></td><td>A result that means a business rule is wrong. Do not continue past it without talking to the business owner.</td></tr>')
raw('</table>')

h3('Who does what')
table(['Who', 'Does', 'Time'], [
    ['Platform admin (once)', 'Step 0 — permissions, upload the package, SQL warehouse', '20 min'],
    ['Implementer (you)', 'Steps 1–7 — everything else in this guide', '~3.5 hours'],
    ['Business owner / KPI owner', 'Signs off the 10 known cases (2.4), supplies real user questions (5.8), runs UAT (8)', '2 hours'],
], ['25%', '55%', '20%'])

h3('The roadmap')
raw('<table class="road"><tr>')
road = [
    ('0', 'Prepare', 'Permissions, upload package, note your names', '20 min'),
    ('1', 'Check data', 'Create schema, profile raw table, confirm formats', '20 min'),
    ('2', 'Silver views', 'Reference tables, typed views, validate, sign off', '45 min'),
    ('3', 'Metric views', 'Governed KPI definitions for TAT, FTR, SLA', '20 min'),
    ('4', 'Semantics', 'Column descriptions so Genie understands', '10 min'),
    ('5', 'Genie space', 'Instructions, expressions, examples, benchmarks', '60 min'),
    ('6', 'Dashboard', 'Six pages built page-by-page from the spec', '60 min'),
    ('7', 'Security', 'Country-level row access', '15 min'),
    ('8', 'Go live', 'UAT checklist and weekly review', '60 min'),
]
for n, t, d, tm in road:
    raw(f'<td><div class="rcard"><div class="n">{n}</div><div class="t">{esc(t)}</div><div class="d">{esc(d)}</div><div class="time">{esc(tm)}</div></div></td>')
raw('</tr></table>')

h3('What you are building')
p('The ingested account-opening table stays untouched. On top of it sit two <b>Silver views</b> (one row per task, one row per case) that apply the business rules once. Two <b>metric views</b> in Unity Catalog hold the governed KPI definitions. Both the <b>dashboard</b> and the <b>Genie space</b> read from those metric views, so a number on a chart and an answer to a typed question always agree.')
table(['Layer', 'Objects', 'Why'], [
    ['Bronze', '<code>&lt;raw_table&gt;</code>', 'Already ingested. Never modified.'],
    ['Reference', '<code>ref_role_team</code>, <code>ref_market_cutoff</code>, <code>ref_user_entitlement</code>', 'Business rules as data — change a row, not code'],
    ['Silver', '<code>v_task_events</code>, <code>v_case_summary</code>', 'Typed timestamps, referral flags, TAT, FTR, SLA due dates'],
    ['Gold', '<code>mv_onboarding_kpis</code>, <code>mv_task_kpis</code>', 'Governed KPIs with synonyms for Genie'],
    ['Consumption', 'Dashboard + Genie space', 'Same definitions, two interfaces'],
], ['18%', '42%', '40%'])
page_end()

# ============================================================ BUSINESS RULES
page_start()
raw('<div class="kicker" style="page-break-before:always">Reference</div><h2>The business rules this solution encodes</h2><div class="rule"></div>')
p('Confirmed with the CIB business owner on 22 October 2026. If any of these change, see Appendix A for the one-line prompt that updates it.')
table(['KPI', 'Rule'], [
    ['<b>Case status</b>', '<code>Case_stage</code> is one of Completed, Pending, Cancelled. <code>Task_Status</code> is Open or Closed.'],
    ['<b>Volumes</b>', 'Count every case regardless of status.'],
    ['<b>Turnaround time (TAT)</b>', 'Completed cases only. From the <i>first task start</i> to the <i>last task end</i>. Calendar hours — weekends, holidays and client wait time all count. Initiated time is <i>not</i> the start.'],
    ['<b>Referral back</b>', 'A queue returns the case to an earlier queue. In the data this is a <i>new task row</i> on the receiving queue with <code>Reason</code> populated. Reason is empty on normal rows.'],
    ['<b>First time right (FTR)</b>', 'A Completed case with zero referrals.'],
    ['<b>SLA due date</b>', 'Initiated before 16:00 market-local → due the same day. Initiated at or after 16:00 → due the next calendar day. Cases received after cutoff are <i>not</i> breaches.'],
    ['<b>SLA breach</b>', 'Not Completed by end of the due date. Excluded from SLA: Cancelled cases, and cases referred back to the Request Initiator.'],
    ['<b>Teams</b>', 'Request Initiator → Client Manager. Request Processor/Checker, Core Banking, Cheque Book, Signatory makers and checkers → CLM Ops. S2B Channel maker/checker → Channels. SLA applies to CLM Ops (Channels to be confirmed).'],
    ['<b>Default dimensions</b>', 'Geography = <code>Booking_Location</code>. Time = initiated date. <code>Client_tier</code> is a priority dimension. Segment/Sub-segment describe the client, not the product.'],
], ['24%', '76%'])
page_end()

# ============================================================ STEP 0
page_start()
stephead('Step 0', 'Before you start', 'Get permissions, upload the package, and write down the four names every prompt will use.')

sub('0.1  Check your permissions', 'ui')
ui(['<b>Catalog</b> (left nav) → your target catalog → <b>Permissions</b> tab.',
    'Confirm you have: <code>USE CATALOG</code>, <code>USE SCHEMA</code>, <code>CREATE TABLE</code>, <code>CREATE VIEW</code>, <code>CREATE FUNCTION</code>.',
    'You also need <b>Can Use</b> on a SQL warehouse and the ability to create Genie spaces and dashboards (standard for Databricks SQL users).'])
warn('Ask your platform admin to grant anything missing before continuing.')

sub('0.2  Upload the implementation package', 'ui')
ui(['Download the <code>scb_onboarding</code> folder you were given (contains <code>sql/</code>, <code>genie/</code>, <code>dashboard/</code>).',
    '<b>Workspace</b> (left nav) → your home folder → <b>⋮ → Import</b> → drag the folder or zip in.',
    'You should now have <code>/Workspace/Users/&lt;you&gt;/scb_onboarding/</code>.'])
expect('Genie Code can read these files when you point it to them. You never copy-paste SQL by hand.')

sub('0.3  Write down your four names', 'ui')
p('Every prompt in this guide uses these placeholders. Fill in the right-hand column now.')
table(['Placeholder', 'Example', 'Yours'], [
    ['<code>&lt;catalog&gt;</code>', '<code>scb_cib</code>', '<span class="fill">________________________</span>'],
    ['<code>&lt;schema&gt;</code>', '<code>account_opening</code>', '<span class="fill">________________________</span>'],
    ['<code>&lt;raw_table&gt;</code>', '<code>acct_opening_raw</code> — the ingested table', '<span class="fill">________________________</span>'],
    ['<code>&lt;warehouse&gt;</code>', '<code>Serverless Starter Warehouse</code>', '<span class="fill">________________________</span>'],
    ['<code>&lt;you&gt;</code>', 'your login email, as shown in the Workspace path', '<span class="fill">________________________</span>'],
], ['22%', '43%', '35%'])
ui(['To find the raw table name: <b>Catalog</b> → browse to the table → copy its three-part name from the top of the page.'], head='Tip')

sub('0.4  Open the SQL Editor', 'ui')
ui(['<b>SQL Editor</b> (left nav) → <b>+ New query</b>.',
    'Pick <code>&lt;warehouse&gt;</code> in the top-right dropdown.',
    'Open Genie Code with the sparkle icon on the right edge. You will stay here for Steps 1–4.'])
page_end()

# ============================================================ STEP 1
page_start()
stephead('Step 1', 'Prepare the schema and check the raw data', 'Create a home for the new objects and make sure the data looks the way the business described it.')

sub('1.1  Create the schema', 'gc')
prompt("""Create a schema called <schema> in catalog <catalog> if it does not already exist, with the comment "CIB account opening analytics — Silver views, metric views and reference data". Then set it as the current catalog and schema for this session and confirm.""")
expect('A <code>CREATE SCHEMA IF NOT EXISTS …</code> statement runs successfully.')

sub('1.2  Profile the raw table', 'gc')
prompt("""Look at the table <catalog>.<schema>.<raw_table>. Tell me:
(1) the row count,
(2) the distinct values and counts for the columns Case_stage, Task_Status, Role, Client_tier, Segment and Booking_Location,
(3) five sample values each of Initiated_time, Start_time and End_time so I can see the timestamp format,
(4) how many rows have _rescued_data populated.
Show the results as tables. Do not change anything.""")
expect('Value lists for each column. <b>Save this output</b> — you will paste it into the Genie space in Step 5.5.')
table(['Column', 'Expected values', 'If different'], [
    ['<code>Case_stage</code>', 'Completed, Pending, Cancelled', 'Note the exact spelling — you will need it'],
    ['<code>Task_Status</code>', 'Open, Closed', 'Note the exact spelling'],
    ['<code>Role</code>', 'The 11 roles from Request Initiator to S2B Channel Checker', 'Any role not in the list → tell the business owner before Step 2'],
    ['Timestamps', 'A consistent format, e.g. <code>2026-10-22 14:05:33</code>', 'Unusual format → do Step 1.3'],
], ['18%', '42%', '40%'])

sub('1.3  Fix the timestamp format (only if 1.2 showed something unusual)', 'gc')
prompt("""Open the file /Workspace/Users/<you>/scb_onboarding/sql/01_reference_tables.sql. The function parse_ts lists the timestamp formats it can read. The raw data uses this format: <paste one sample, e.g. 22-OCT-2026 14:05:33>. Add a matching try_to_timestamp pattern as the FIRST entry in the COALESCE and show me the edited function. Do not run it yet.""")
page_end()

# ============================================================ STEP 2
page_start()
stephead('Step 2', 'Reference tables and Silver views', 'Apply the business rules once, in two views, and prove they are right on cases the business already knows.')

sub('2.1  Create the reference tables and helper function', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/sql/01_reference_tables.sql. Replace every occurrence of scb_cib.account_opening with <catalog>.<schema>, "USE CATALOG scb_cib" with "USE CATALOG <catalog>", "USE SCHEMA account_opening" with "USE SCHEMA <schema>", and acct_opening_raw with <raw_table>. Then run the whole script. Afterwards show me the contents of ref_role_team and ref_market_cutoff.""")
expect('<b>11 rows</b> in <code>ref_role_team</code> (each role mapped to Client Manager, CLM Ops or Channels) and one row per booking location in <code>ref_market_cutoff</code>, all showing <code>16:00:00</code>.')
warn('If your Role values are spelled differently from the 11 in the table (for example <code>CORE_BANKING_MAKER</code>), paste this:')
prompt("""In <catalog>.<schema>.ref_role_team the role column must match the raw data exactly. The raw values are: <paste the Role list from Step 1.2>. Update the table so each raw value maps to the right team using this logic: Request Initiator → Client Manager; Processor, Checker, Core Banking, Cheque Book and Signatory roles → CLM Ops; S2B roles → Channels. Keep role_order in process sequence. Show me the result.""", head="Fix prompt — only if roles differ")

sub('2.2  Create the Silver views', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/sql/02_silver_views.sql. Apply the same replacements as before (scb_cib.account_opening → <catalog>.<schema>, the catalog and schema in the USE statements, acct_opening_raw → <raw_table>). If the raw column for cheque book is not exactly Cheque_book_required, replace it with the real column name. Then run the script and confirm both views v_task_events and v_case_summary were created. Finally run: SELECT * FROM v_case_summary LIMIT 5""")
expect('Two views created. Five case rows with columns such as <code>case_tat_hrs</code>, <code>is_ftr</code>, <code>sla_due_date</code>, <code>is_sla_breach</code>.')
page_end()

page_start()
sub('2.3  Validate the data', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/sql/05_validation.sql, apply the catalog and schema replacements, and run queries 1 to 8 one at a time. For each, show me the result and one line saying whether it looks healthy. Flag anything where more than 1% of timestamps failed to parse, where a Role is missing from ref_role_team, where Reason appears on a case's first task, or where any task duration is negative.""")
table(['Check', 'Healthy', 'If not'], [
    ['Q1 — unparsed timestamps', '≈ 0', 'Go back to 1.3, add the format, re-run 2.1 and 2.2'],
    ['Q4 — roles not mapped', '0 rows', 'Run the fix prompt in 2.1'],
    ['Q5 — <code>reason_on_first_task</code>', '0', 'See the red box'],
    ['Q8 — negative durations', '0 or a handful', 'Note the case numbers for the data team; proceed'],
], ['32%', '18%', '50%'])
stop('<b>Q5 is greater than zero.</b> It means Reason is sometimes populated on a case\'s first task, so "Reason present = referral" does not hold and the FTR logic must change. Tell the business owner and your Databricks contact before going further.')

sub('2.4  Sign off on ten known cases', 'biz')
p('Ask the business owner for <b>5 case numbers they know were straight-through</b> and <b>5 they know were referred back</b>. Then:')
prompt("""From <catalog>.<schema>.v_case_summary show case_no, case_stage, initiated_ts, first_start_ts, last_end_ts, case_tat_hrs, referral_count, is_ftr, received_after_cutoff, sla_due_date and is_sla_breach for these cases: <paste the 10 case numbers>. Then, for the first referred case, show its full task history from v_task_events ordered by task_seq.""")
expect('Walk through the output with the business owner. The 5 straight-through cases show <code>is_ftr = true</code> and <code>referral_count = 0</code>; the 5 referred cases show the opposite, and the task history shows the referral row with its Reason.')
stop('<b>The business owner disagrees with any TAT, FTR or SLA flag.</b> Everything downstream inherits these rules. Resolve the disagreement first.')
page_end()

# ============================================================ STEP 3
page_start()
stephead('Step 3', 'Metric views — the governed KPI definitions', 'Put the four KPIs in Unity Catalog once, with synonyms, so the dashboard and Genie can never disagree.')

sub('3.1  Create the case-level metric view', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/sql/03_mv_onboarding_kpis.sql. Replace scb_cib.account_opening with <catalog>.<schema> everywhere, including inside the YAML "source:" line. Run it. If the workspace rejects "version: 1.1", change it to "version: 1.0", remove all "synonyms:" lines, run again, and tell me you did that. Confirm mv_onboarding_kpis exists.""")

sub('3.2  Create the task-level metric view', 'gc')
prompt("""Do the same for /Workspace/Users/<you>/scb_onboarding/sql/04_mv_task_kpis.sql and confirm mv_task_kpis exists.""")

sub('3.3  Smoke-test the KPIs', 'gc')
prompt("""Run validation query 9 from 05_validation.sql (the two metric view queries). Then tell me in plain English: total cases, completed cases, overall FTR rate, overall SLA breach rate, and the team with the biggest backlog.""")
expect('Sensible numbers: FTR somewhere between 0 and 100%, breach rate well below 100%, backlog concentrated in CLM Ops roles.')
warn('FTR exactly 0% or exactly 100% almost always means the Reason rule is wrong. Revisit 2.3 Q5.')

sub('3.4  Certify the views', 'ui')
ui(['<b>Catalog</b> → <code>&lt;catalog&gt;.&lt;schema&gt;</code> → <code>mv_onboarding_kpis</code> → <b>⋮ → Certify</b> (if your workspace offers certification).',
    'Repeat for <code>mv_task_kpis</code> and <code>v_case_summary</code>.'])
expect('A certified badge next to the three objects in Genie and in the dashboard dataset picker.')

stephead('Step 4', 'Column semantics', 'Teach Genie what every column means and when not to use it.')
sub('4.1  Apply comments and tags', 'ui')
ui(['<b>Workspace</b> → <code>scb_onboarding/genie/</code> → open <code>05_column_semantics.sql</code>. It opens in the file editor.',
    'Press <code>Cmd/Ctrl + F</code>, turn on <b>Replace</b>, and replace <code>scb_cib</code> with <code>&lt;catalog&gt;</code> and <code>account_opening</code> with <code>&lt;schema&gt;</code> (Replace All for each).',
    'Select the whole file (<code>Cmd/Ctrl + A</code>), copy, and paste it into a new query in the <b>SQL Editor</b> with <code>&lt;warehouse&gt;</code> attached.',
    'Click <b>Run all</b>. The statements run one after another; it takes under a minute.'])
expect('About 50 <code>COMMENT ON COLUMN</code> statements and three <code>ALTER VIEW … SET TAGS</code> statements succeed. Open <b>Catalog</b> → <code>v_case_summary</code> → <b>Columns</b> tab — every column now has a description.')
warn('One statement fails with "column does not exist"? That column name differs in your data (most likely the cheque-book column). Delete that single line and run again; nothing else depends on it.')
page_end()

# ============================================================ STEP 5
page_start()
stephead('Step 5', 'Genie space — natural-language questions', 'Create the space, load the semantics, and measure accuracy with benchmarks before anyone uses it.')

sub('5.1  Create the space', 'ui')
ui(['Left nav → <b>Genie</b> → <b>+ New</b> → <b>Genie space</b>.',
    'Title: <code>CIB Account Opening Analytics</code>.',
    'Add data <b>in this order</b>: <code>mv_onboarding_kpis</code>, then <code>mv_task_kpis</code>, then <code>v_case_summary</code>.',
    '<b>Do not add</b> the raw table, <code>v_task_events</code> or any <code>ref_</code> table.',
    'Warehouse: <code>&lt;warehouse&gt;</code>. Save.'])

sub('5.2  Open Genie Code inside the space', 'ui')
ui(['In the space, click <b>Configure</b> (top right).',
    'Open the Genie Code panel (sparkle icon). It can now edit this space\'s settings directly.',
    'Every prompt in 5.3 to 5.8 is pasted here, not in the SQL Editor.'])

sub('5.3  Description, sample questions and general instructions', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/genie/01_space_setup.md. Apply to this Genie space: (1) the Description from section 2, (2) the five Sample questions from section 2, (3) the General instructions text block from section 3, exactly as written. Show me what you set.""")

sub('5.4  SQL expressions', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/genie/02_sql_expressions.sql. Each block is a SQL expression for this space's knowledge store: the comment line gives the type (FILTER, MEASURE or DIMENSION), the name, and a "use when the user says" description; the SQL below it is the expression. Add all of them to this space with those names and descriptions. Where a block is marked "(mv_task_kpis)" attach it to that table; otherwise attach it to v_case_summary. List what you added.""")
expect('Roughly 20 filters, 7 measures and 5 dimensions listed under Configure → Instructions → SQL expressions.')
page_end()

page_start()
sub('5.5  Value dictionaries', 'gc')
p('This is the single highest-impact accuracy step. It stops Genie guessing <i>SG</i> vs <i>Singapore</i> or <i>PLAT</i> vs <i>Platinum</i>.')
prompt("""For the data assets in this space, add the following as the known values for these columns so you never guess literals:
<paste the Step 1.2 output for Case_stage, Task_Status, Role, Client_tier, Segment and Booking_Location>
Also add Team values: Client Manager, CLM Ops, Channels. Mark Platinum (or your equivalent top tier) as the highest-priority tier in its description.""")

sub('5.6  Example queries', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/genie/03_example_queries.sql. Each "-- Q:" line is a user question and the SQL below it is the correct answer. Replace any literal values marked "confirm literal" (such as 'Singapore' or 'Platinum') with the real values from the value dictionary you just added. Then add all pairs as Example SQL queries in this space.""")

sub('5.7  Load benchmarks and run them', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/genie/04_benchmarks.json. For every entry that has expected_sql, create a benchmark in this space with the question and that SQL as the expected answer, after replacing the literals listed in confirm_literals with real values. For entries that only have expected_behaviour, add the question as a benchmark with no SQL and put the expected behaviour in the notes. Then run all benchmarks and give me the pass rate and the list of failures.""")
expect('A pass rate. <b>Target is 90% or higher</b> before UAT.')
warn('For each failure, paste this and let Genie Code triage it:')
prompt("""Benchmark <id> failed. Compare Genie's SQL with the expected SQL and tell me whether the fix belongs in (a) a metric view synonym or comment, (b) a value dictionary entry, (c) a SQL expression, or (d) an example query. Recommend the smallest change and apply it if it is (b), (c) or (d). If it is (a), give me the exact ALTER VIEW or YAML change to run in the SQL Editor.""", head="Fix prompt — one per failed benchmark")
p('Re-run the benchmarks after each round of fixes. Stop when you are at 90% or better and understand the remaining failures.')

sub('5.8  Replace the seed questions with the real ones', 'biz')
p('When the business owner sends the list of questions users actually ask:')
prompt("""Here are the questions our users actually ask: <paste the business owner's list>. For each one, write the correct SQL against the assets in this space, add it as a benchmark, and run it. Report the pass rate and the failures.""")

sub('5.9  Share the space', 'ui')
ui(['Space → <b>Share</b>.',
    'Add the operations and management groups with <b>Can Run</b>.',
    'Add two named owners with <b>Can Edit</b>.'])
page_end()

# ============================================================ STEP 6
page_start()
stephead('Step 6', 'Dashboard', 'Six pages built one at a time from the spec, reading the same metric views as Genie.')

sub('6.1  Create the dashboard and add the metric-view datasets', 'ui')
ui(['Left nav → <b>Dashboards</b> → <b>Create dashboard</b>. Name it <code>CIB Account Opening Control Tower</code>.',
    'Open the <b>Data</b> tab → <b>+ Add data</b> → choose <code>&lt;catalog&gt;.&lt;schema&gt;.mv_onboarding_kpis</code> (shown as a metric view). Rename the dataset to <code>kpi</code>.',
    'Repeat for <code>mv_task_kpis</code> → rename to <code>task</code>.',
    'Still in the Data tab, open Genie Code (sparkle icon) and paste the prompt below.'])
p('<small>Why add metric views directly? Filtering the dashboard by tier or market then recomputes rates from the underlying cases instead of averaging pre-computed percentages.</small>')

sub('6.1 (cont.)  Add the SQL datasets', 'gc')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/dashboard/02_datasets.sql. It contains six named SQL datasets: cases, funnel, kpi_prev, reasons, journey and last_updated. Create each one as a dataset in this dashboard with that exact name, after replacing scb_cib.account_opening with <catalog>.<schema>. Create the dashboard parameters they use: date_from (date, default 30 days ago), date_to (date, default today) and case_no (string, default empty). Run each dataset once to confirm it returns rows.""")
expect('Eight datasets in the Data tab: <code>kpi</code>, <code>task</code>, <code>cases</code>, <code>funnel</code>, <code>kpi_prev</code>, <code>reasons</code>, <code>journey</code>, <code>last_updated</code>.')

sub('6.2  Build Page 1', 'gc')
ui(['Switch to the <b>Canvas</b> tab. Open Genie Code (sparkle icon).'], head='First')
prompt("""Open /Workspace/Users/<you>/scb_onboarding/dashboard/01_dashboard_spec.md. Build "Page 1 — Executive Summary" exactly as specified in that section: create the page, add every widget in the table using the dataset, type, measures and dimensions listed, apply the formatting from the "Formatting & conventions" section, and arrange them using the Layout line. Add the global filters from the "Global filters" section to the top of the page, bound to the kpi and cases datasets. When done, list the widgets you created.""")
expect('Four KPI counters across the top, a status donut, two trend charts, a market scorecard table and a heatmap — all showing numbers.')
page_end()

page_start()
sub('6.2 (cont.)  Build Pages 2 to 6', 'gc')
p('Paste each of these in turn. Wait for one page to finish and check it renders before starting the next.')
prompt("""Using the same spec file, build "Page 2 — Pipeline & Backlog" as specified, including the global filters.""", head="Page 2")
prompt("""Using the same spec file, build "Page 3 — Turnaround Time" as specified, including the global filters. Fix the status filter on this page to Completed, as the spec says.""", head="Page 3")
prompt("""Using the same spec file, build "Page 4 — First Time Right" as specified, including the global filters. If a Sankey widget is not available in this workspace, use the heatmap table fallback described in the spec for widget 4.9.""", head="Page 4")
prompt("""Using the same spec file, build "Page 5 — SLA" as specified, including the global filters.""", head="Page 5")
prompt("""Using the same spec file, build "Page 6 — Case Explorer" as specified. Bind widget 6.1 to the case_no parameter and widget 6.3 to the journey dataset. Leave space on the right for the Genie panel.""", head="Page 6")
warn('A widget shows no data? Paste this:')
prompt("""Widget <name> on page <n> shows no data. Check which dataset and fields it uses, run the underlying query, and fix the binding or the query.""", head="Fix prompt — blank widget")

sub('6.3  Connect Genie to the dashboard', 'ui')
ui(['Dashboard → <b>⋮ → Settings</b> (or the Genie icon in the toolbar) → <b>Genie space</b>.',
    'Choose <code>CIB Account Opening Analytics</code> — the space you configured in Step 5, <b>not</b> the auto-generated one.'])

sub('6.4  Publish', 'ui')
ui(['<b>Publish</b> → select <b>Don\'t embed credentials</b> so each viewer\'s row-level security applies.',
    '<b>Publish</b>. Then <b>Share</b> with the same groups as the Genie space.'])
expect('The published link opens for an operations user and shows data for their market only (after Step 7).')
page_end()

# ============================================================ STEP 7 + 8
page_start()
stephead('Step 7', 'Security — operational users see only their markets', 'Global heads see everything; country teams see their own bookings. One table controls it.')

sub('7.1  Fill the entitlement table', 'gc')
prompt("""Insert rows into <catalog>.<schema>.ref_user_entitlement.
Global users who see everything: <list of user emails or group names> with is_global = TRUE.
Operational users: <user or group → booking location pairs, e.g. sg-ops-team → Singapore> with is_global = FALSE.
Show me the table afterwards.""")

sub('7.2  Attach the row filter', 'gc')
prompt("""Attach the row filter function <catalog>.<schema>.rf_booking_location to the table <catalog>.<schema>.<raw_table> on its Booking_Location column so that every view built on it inherits the restriction. Then confirm by running SELECT DISTINCT booking_location FROM <catalog>.<schema>.v_case_summary and tell me what I, as the current user, can see.""")
expect('Ask one operational user and one global user to open the dashboard. The first sees one market; the second sees all.')

stephead('Step 8', 'UAT and go-live', 'One hour with the business owner, then a weekly habit.', brk=False)
sub('8.1  UAT checklist', 'biz')
table(['#', 'Test', 'Pass'], [
    ['1', 'Page 1 total cases this month matches the existing manual report (allowing for known exclusions)', '<span class="fill">☐</span>'],
    ['2', 'The 10 known cases from Step 2.4 show correct TAT, FTR and SLA flags in Case Explorer', '<span class="fill">☐</span>'],
    ['3', 'FTR rate on Page 4 matches the business\'s current calculation for the same period', '<span class="fill">☐</span>'],
    ['4', 'A case initiated after 16:00 shows <code>sla_due_date</code> = next day and is <b>not</b> breached', '<span class="fill">☐</span>'],
    ['5', 'A case referred back to Request Initiator is <b>excluded</b> from the SLA population', '<span class="fill">☐</span>'],
    ['6', 'Operational user sees only their market; global user sees all', '<span class="fill">☐</span>'],
    ['7', 'Ask Genie the 5 sample questions — answers match the dashboard numbers', '<span class="fill">☐</span>'],
    ['8', 'Ask Genie "which RM has the most breaches" — it says RM names are not in the data', '<span class="fill">☐</span>'],
], ['6%', '84%', '10%'])

sub('8.2  Go-live habits', 'ui')
ui(['Nominate one owner to check the Genie space <b>Monitoring</b> tab every Monday for thumbs-down answers, and re-run benchmarks (prompt 5.7) after any change.',
    'In the SQL Editor, record what was deployed:'], head='Set up')
prompt("""Show me the current definitions of mv_onboarding_kpis and mv_task_kpis and save them to /Workspace/Users/<you>/scb_onboarding/deployed/ with today's date in the filename.""")
page_end()

# ============================================================ APPENDICES
page_start()
raw('<div class="kicker" style="page-break-before:always">Appendix A</div><h2>Changing the rules later</h2><div class="rule"></div>')
p('All of these are run in the SQL Editor with Genie Code, unless stated.')
table(['Change', 'Prompt'], [
    ['A market gets a different cutoff', '<code>Update ref_market_cutoff: set cutoff_local_time to \'15:00:00\' for booking_location \'Hong Kong\'.</code>'],
    ['A new role appears in the data', '<code>Add role \'&lt;name&gt;\' to ref_role_team mapped to team \'&lt;team&gt;\' with role_order &lt;n&gt; and sla_applicable &lt;true/false&gt;.</code>'],
    ['SLA should also apply to Channels', '<code>Set sla_applicable = TRUE for the Channels team in ref_role_team.</code>'],
    ['Users call a KPI by a new name', '<code>In the metric view mv_onboarding_kpis, add the synonym \'cycle time\' to the measure avg_tat_hrs and recreate the view.</code>'],
    ['A Genie question keeps failing', 'In the Genie space → Genie Code: use the fix prompt from 5.7'],
    ['Dashboard has become slow', '<code>Convert v_case_summary into a materialized view refreshed every 15 minutes, keeping the same name and columns.</code>'],
    ['FTR / SLA targets agreed', 'In the dashboard → Genie Code: <code>Add a reference line at &lt;x&gt;% on widgets 1.3, 4.1 and 5.1 and colour the counters red below it.</code>'],
], ['30%', '70%'])

raw('<div class="kicker" style="margin-top:22px">Appendix B</div><h2>Troubleshooting prompts</h2><div class="rule"></div>')
table(['Symptom', 'Paste into Genie Code'], [
    ['"Permission denied"', '<code>Tell me which privilege is missing for this statement and who can grant it.</code>'],
    ['Metric view will not create', '<code>Explain this error. If it is the YAML version, downgrade to 1.0 and remove synonyms; if it is a measure expression, show me which one and propose a fix.</code>'],
    ['Numbers differ from the old report', '<code>Compare the row count and completed-case count in v_case_summary for &lt;month&gt; against &lt;raw_table&gt; grouped by Case_stage, and list any cases present in one but not the other.</code>'],
    ['Genie gives a wrong answer', '<code>Show me the SQL you generated, explain which instruction or example you used, and tell me what context would have made you choose the right table or measure.</code>'],
], ['30%', '70%'])
page_end()

page_start()
raw('<div class="kicker" style="page-break-before:always">Appendix C</div><h2>Glossary</h2><div class="rule"></div>')
table(['Term', 'Meaning'], [
    ['Case', 'One client request to open one or more accounts'],
    ['Task', 'One unit of work on a case by one role; a case has many tasks'],
    ['Referral back', 'A queue returns the case to an earlier queue; creates a new task row with a Reason'],
    ['FTR', 'First Time Right — a Completed case with zero referrals'],
    ['TAT', 'Turnaround time — first task start to last task end, calendar hours, Completed cases only'],
    ['SLA due date', 'Initiated date if initiated before 16:00 local, otherwise the next day'],
    ['Metric view', 'A governed KPI definition in Unity Catalog; dashboard and Genie both read it so numbers agree'],
    ['Genie space', 'The natural-language question interface for business users'],
    ['Genie Code', 'The AI assistant that writes and runs code for you inside Databricks'],
    ['Benchmark', 'A test question with a known correct answer, used to measure Genie\'s accuracy'],
    ['Value dictionary', 'The list of real values in a column, given to Genie so it never guesses spellings'],
    ['Row-level security', 'A filter that limits which rows each user can see, applied once at the table and inherited everywhere'],
], ['22%', '78%'])

raw('<div class="kicker" style="margin-top:22px">Appendix D</div><h2>Package contents</h2><div class="rule"></div>')
table(['File', 'Used in step', 'What it is'], [
    ['<code>sql/01_reference_tables.sql</code>', '2.1', 'Timestamp parser, role→team map, market cutoffs, entitlement table, row filter'],
    ['<code>sql/02_silver_views.sql</code>', '2.2', '<code>v_task_events</code> and <code>v_case_summary</code>'],
    ['<code>sql/03_mv_onboarding_kpis.sql</code>', '3.1', 'Case-level metric view'],
    ['<code>sql/04_mv_task_kpis.sql</code>', '3.2', 'Task/queue-level metric view'],
    ['<code>sql/05_validation.sql</code>', '2.3, 3.3', 'Ten validation queries'],
    ['<code>genie/01_space_setup.md</code>', '5.3', 'Description, sample questions, general instructions'],
    ['<code>genie/02_sql_expressions.sql</code>', '5.4', 'Reusable filters, measures, dimensions'],
    ['<code>genie/03_example_queries.sql</code>', '5.6', '18 question → SQL pairs'],
    ['<code>genie/04_benchmarks.json</code>', '5.7', '35 test questions with expected answers'],
    ['<code>genie/05_column_semantics.sql</code>', '4.1', 'Column descriptions and tags'],
    ['<code>dashboard/01_dashboard_spec.md</code>', '6.2', 'Six-page widget-by-widget specification'],
    ['<code>dashboard/02_datasets.sql</code>', '6.1', 'Six SQL datasets with parameters'],
], ['36%', '12%', '52%'])
raw('<div class="footer-note">Prepared by Databricks Solutions Architecture for Standard Chartered Bank, CIB. Business rules as confirmed on 22 October 2026. Questions: contact your Databricks account team.</div>')
page_end()

HTML = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{''.join(out)}</body></html>"""
open('/home/claude/scb_onboarding/guide.html', 'w').write(HTML)

subprocess.run([
    'wkhtmltopdf', '--quiet', '--page-size', 'A4', '--margin-top', '16mm', '--margin-bottom', '16mm',
    '--margin-left', '18mm', '--margin-right', '18mm', '--enable-local-file-access', 
    '--footer-font-name', 'Carlito', '--footer-font-size', '8', '--footer-spacing', '4',
    '--footer-left', '  CIB Account Opening Control Tower — Implementation Guide',
    '--footer-right', 'Page [page] of [topage]  ',
    '/home/claude/scb_onboarding/guide.html',
    '/home/claude/scb_onboarding/CIB_Account_Opening_Implementation_Guide.pdf'
], check=True)
print('done')

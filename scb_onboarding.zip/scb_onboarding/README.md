# SCB CIB Account Opening — Silver layer + Metric Views

Run in order on a Databricks SQL warehouse (DBR 17+ / current channel). Replace
`scb_cib.account_opening` with the target catalog.schema and `acct_opening_raw`
with the bronze table name.

| File | Creates |
|---|---|
| `01_reference_tables.sql` | `parse_ts()` function, `ref_role_team`, `ref_market_cutoff`, `ref_user_entitlement`, `rf_booking_location()` row filter |
| `02_silver_views.sql` | `v_task_events` (task grain), `v_case_summary` (case grain) |
| `03_mv_onboarding_kpis.sql` | Metric view: Volumes, TAT, FTR, SLA at case level |
| `04_mv_task_kpis.sql` | Metric view: task/queue KPIs, referral flows, team FTR |
| `05_validation.sql` | Checks to run before UAT |

## Business rules encoded (confirmed 22 Oct 2026)

- **Case status** = `Case_stage` ∈ {Completed, Pending, Cancelled}. `Task_Status` ∈ {Open, Closed}.
- **Volumes** count all cases. **TAT** = Completed only, first task start → last task end, calendar hours (weekends/holidays/client wait included).
- **Referral** = new task row on the receiving queue with `Reason` populated. **FTR** = Completed and zero referrals.
- **SLA due date** = initiated date if initiated before 16:00 market-local, else next day. Breach = not Completed by due date. Excluded: Cancelled, and cases referred back to Request Initiator.
- **Teams**: Request Initiator → Client Manager; Processor/Checker/Core Banking/Cheque Book/Signatory → CLM Ops; S2B → Channels. SLA applies to CLM Ops only (Channels TBC).
- **Default geography** = `Booking_Location`. `Client_tier` is a priority dimension. Segment/Sub_Segment are client segments.
- Timestamps are **market-local**, kept as-is.

## Assumptions to confirm

1. Source timestamp string format — `parse_ts()` covers common ones; run validation query 1–2.
2. Referral to Request Initiator is identified by `Role = 'Request Initiator'` on the referral row.
3. `Reason` is never populated on a non-referral row (validation query 5 checks this).
4. FTR excludes Cancelled cases.
5. Exact column name of the truncated `Cheque_book_requir…` field.
6. `current_date()` runs in the warehouse timezone; set it to the primary market or add a tz lookup.

## Notes

- Views are plain SQL (zero pipeline). Switch `CREATE OR REPLACE VIEW v_case_summary` to
  `CREATE OR REPLACE MATERIALIZED VIEW ... SCHEDULE EVERY 15 MINUTES` if latency becomes an issue.
- Metric views use `version: 1.1` (synonyms). If the workspace rejects it, drop `synonyms` and use `version: 1.0`.
- Row-level security: attach `rf_booking_location` to the bronze table (preferred) so every view inherits it.

# CIB Account Opening Control Tower — Step-by-Step Implementation Guide

**For:** Standard Chartered CIB team deploying on Databricks
**How it works:** Every step is either a click path in the Databricks UI or a prompt you paste
into **Genie Code** (the AI assistant panel inside Databricks, opened with the ✨ icon on the
right of the screen or `Cmd/Ctrl + I`). You do not need to write SQL. You read what Genie Code
produces, check it against the "What you should see" box, and move on.

**Time:** ~4 hours of hands-on work spread over 1–2 weeks (waiting for business sign-offs is
the long pole, not the clicks).

**Roles:**

| Who | Does |
|---|---|
| Platform admin (once) | Steps 0.1–0.3 — permissions, upload, SQL warehouse |
| Implementer (you) | Everything else |
| Business owner (Ketan / KPI owner) | Signs off Step 2.4 numbers, provides benchmark questions in Step 5.6, UAT in Step 8 |

---

## Step 0 — Before you start

### 0.1 Check you have the right permissions  *(UI)*

You need, on the target catalog: `USE CATALOG`, `USE SCHEMA`, `CREATE TABLE`, `CREATE VIEW`,
`CREATE FUNCTION`. You also need `Can Use` on a SQL warehouse, and the ability to create Genie
spaces and dashboards (standard for Databricks SQL users).

**Where:** Catalog → your catalog → Permissions tab. If anything is missing, ask your platform admin.

### 0.2 Upload the implementation package  *(UI)*

1. Download the `scb_onboarding` folder you were given (contains `sql/`, `genie/`, `dashboard/`).
2. Databricks → **Workspace** → your home folder → **⋮ → Import** → drag the whole folder in
   (or import the zip). You should end up with `/Workspace/Users/<you>/scb_onboarding/`.

Genie Code can read these files when you point it to them, so you never have to copy-paste SQL.

### 0.3 Confirm the names you'll use  *(UI)*

Write these down; every prompt below uses them:

| Placeholder | Example | Yours |
|---|---|---|
| `<catalog>` | `scb_cib` | |
| `<schema>` | `account_opening` | |
| `<raw_table>` | `acct_opening_raw` (the ingested table from the screenshot) | |
| `<warehouse>` | `Serverless Starter Warehouse` | |

Find the raw table in **Catalog** → browse to it → copy its three-part name from the top of the page.

### 0.4 Open the SQL Editor and attach a warehouse  *(UI)*

**SQL Editor** (left nav) → new query → pick `<warehouse>` top-right → open Genie Code (✨).
You'll stay in this screen for Steps 1–4.

---

## Step 1 — Prepare the schema and check the raw data

### 1.1 Create the schema  *(Genie Code prompt)*

> Create a schema called `<schema>` in catalog `<catalog>` if it does not already exist, with the
> comment "CIB account opening analytics — Silver views, metric views and reference data". Then set
> it as the current catalog and schema for this session and confirm.

**What you should see:** a `CREATE SCHEMA IF NOT EXISTS …` statement runs successfully.

### 1.2 Profile the raw table  *(Genie Code prompt)*

> Look at the table `<catalog>.<schema>.<raw_table>`. Tell me: (1) row count, (2) the distinct
> values and counts for columns Case_stage, Task_Status, Role, Client_tier, Segment and
> Booking_Location, (3) five sample values each of Initiated_time, Start_time and End_time so I can
> see the timestamp format, (4) how many rows have _rescued_data populated. Show results as tables,
> do not change anything.

**What you should see:** value lists. **Save this output** — you'll paste it into Genie in Step 5.5.

**Check against the business rules:**
- `Case_stage` should have only Completed / Pending / Cancelled (spelling may differ — note it).
- `Task_Status` should be Open / Closed.
- `Role` should match the 11 roles in the team mapping (Request Initiator … S2B Channel Checker).
  If a role appears that isn't in that list, tell the business owner before continuing.

### 1.3 Fix the timestamp format if needed  *(Genie Code prompt — only if 1.2 showed an unusual format)*

> Open the file `/Workspace/Users/<you>/scb_onboarding/sql/01_reference_tables.sql`. The function
> `parse_ts` lists timestamp formats it can read. The raw data uses this format: `<paste a sample,
> e.g. 22-OCT-2026 14:05:33>`. Add a matching `try_to_timestamp` pattern as the FIRST entry in the
> COALESCE and show me the edited function. Do not run it yet.

---

## Step 2 — Reference tables and Silver views

### 2.1 Create the reference tables and helper function  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/sql/01_reference_tables.sql`. Replace every
> occurrence of `scb_cib.account_opening` with `<catalog>.<schema>`, `USE CATALOG scb_cib` with
> `USE CATALOG <catalog>`, `USE SCHEMA account_opening` with `USE SCHEMA <schema>`, and
> `acct_opening_raw` with `<raw_table>`. Then run the whole script. Afterwards show me the
> contents of `ref_role_team` and `ref_market_cutoff`.

**What you should see:** 11 rows in `ref_role_team` (one per role, mapped to Client Manager /
CLM Ops / Channels) and one row per booking location in `ref_market_cutoff`, all with `16:00:00`.

**If the Role values in your data are spelled differently** from the 11 in the table (e.g.
`CORE_BANKING_MAKER`), run:

> In `<catalog>.<schema>.ref_role_team`, the `role` column must match the raw data exactly. The
> raw values are: `<paste the Role list from Step 1.2>`. Update the table so each raw value maps to
> the right team using the same mapping logic (Request Initiator → Client Manager; Processor,
> Checker, Core Banking, Cheque Book, Signatory → CLM Ops; S2B → Channels). Show me the result.

### 2.2 Create the Silver views  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/sql/02_silver_views.sql`. Apply the same
> replacements as before (`scb_cib.account_opening` → `<catalog>.<schema>`, catalog/schema in
> the USE statements, `acct_opening_raw` → `<raw_table>`). If the raw column for cheque book is
> not exactly `Cheque_book_required`, replace it with the real column name. Then run the script
> and confirm both views `v_task_events` and `v_case_summary` were created. Finally run
> `SELECT * FROM v_case_summary LIMIT 5`.

**What you should see:** two views created; five case rows with columns like `case_tat_hrs`,
`is_ftr`, `sla_due_date`, `is_sla_breach`.

### 2.3 Validate the data  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/sql/05_validation.sql`, apply the catalog/schema
> replacements, and run queries 1 to 8 one at a time. For each, show me the result and one line
> saying whether it looks healthy. Flag anything where more than 1% of timestamps failed to parse,
> where a Role is missing from ref_role_team, where Reason appears on a case's first task, or where
> task durations are negative.

**What you should see / decide:**

| Check | Healthy | If not |
|---|---|---|
| Q1 unparsed timestamps | ≈ 0 | Go back to 1.3, add the format, re-run 2.1 and 2.2 |
| Q4 roles not mapped | 0 rows | Run the role-fix prompt in 2.1 |
| Q5 `reason_on_first_task` | 0 | **Stop.** Tell the business owner — the "Reason = referral" rule doesn't hold and FTR logic must change |
| Q8 negative durations | 0 or a handful | Note the case numbers for the data team; proceed |

### 2.4 Business sign-off on known cases  *(Genie Code prompt, then a meeting)*

Ask the business owner for 5 case numbers they know were straight-through and 5 they know were
referred back. Then:

> From `<catalog>.<schema>.v_case_summary`, show case_no, case_stage, initiated_ts, first_start_ts,
> last_end_ts, case_tat_hrs, referral_count, is_ftr, received_after_cutoff, sla_due_date,
> is_sla_breach for these cases: `<paste the 10 case numbers>`. Then for the first referred case
> show its full task history from v_task_events ordered by task_seq.

Walk through the output with the business owner. **Do not continue until they agree the TAT,
FTR and SLA flags are right for these ten cases.** Everything downstream inherits these rules.

---

## Step 3 — Metric views (the governed KPI definitions)

### 3.1 Create the case-level metric view  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/sql/03_mv_onboarding_kpis.sql`. Replace
> `scb_cib.account_opening` with `<catalog>.<schema>` everywhere, including inside the YAML
> `source:` line. Run it. If the workspace rejects `version: 1.1`, change it to `version: 1.0`,
> remove all `synonyms:` lines, and run again — then tell me you did that. Confirm
> `mv_onboarding_kpis` exists.

### 3.2 Create the task-level metric view  *(Genie Code prompt)*

> Do the same for `/Workspace/Users/<you>/scb_onboarding/sql/04_mv_task_kpis.sql` and confirm
> `mv_task_kpis` exists.

### 3.3 Smoke-test the KPIs  *(Genie Code prompt)*

> Run validation query 9 from `05_validation.sql` (the two metric view queries). Then tell me in
> plain English: total cases, completed cases, overall FTR rate, overall SLA breach rate, and the
> team with the biggest backlog.

**What you should see:** sensible numbers. FTR between 0 and 100%, breach rate not 100%, backlog
concentrated in CLM Ops roles. If FTR is exactly 0% or 100%, the Reason rule is probably wrong —
revisit 2.3 Q5.

### 3.4 Certify the views  *(UI)*

**Catalog** → `<catalog>.<schema>` → `mv_onboarding_kpis` → **⋮ → Certify** (if your workspace
has certification). Repeat for `mv_task_kpis` and `v_case_summary`. This puts a badge on them in
Genie and the dashboard dataset picker.

---

## Step 4 — Column semantics (teaches Genie what the columns mean)

### 4.1 Apply comments and tags  *(UI)*

1. **Workspace** → `scb_onboarding/genie/` → open `05_column_semantics.sql` in the file editor.
2. `Cmd/Ctrl + F` → turn on **Replace** → replace `scb_cib` with `<catalog>` and `account_opening`
   with `<schema>` (Replace All for each).
3. Select all, copy, paste into a new query in the **SQL Editor** with `<warehouse>` attached.
4. **Run all**.

**What you should see:** ~50 `COMMENT ON COLUMN` and three `ALTER VIEW … SET TAGS` statements
succeed. Open `v_case_summary` in Catalog Explorer and confirm the Columns tab shows descriptions.

**If one statement fails with "column does not exist":** that column is named differently in your
data (most likely the cheque-book column). Delete that line and run again.

---

## Step 5 — Genie space (natural-language questions)

### 5.1 Create the space  *(UI)*

1. Left nav → **Genie** → **+ New** → **Genie space**.
2. Title: `CIB Account Opening Analytics`.
3. Add data — in this order: `mv_onboarding_kpis`, then `mv_task_kpis`, then `v_case_summary`.
   **Do not add the raw table or `v_task_events`.**
4. Warehouse: `<warehouse>`. Save.

### 5.2 Open Genie Code inside the space  *(UI)*

In the space, click **Configure** (top right), then open the Genie Code panel (✨). Genie Code can
now edit this space's settings directly. Every prompt in Steps 5.3–5.7 is pasted here.

### 5.3 Set description, sample questions and general instructions  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/genie/01_space_setup.md`. Apply to this Genie space:
> (1) the Description from section 2, (2) the five Sample questions from section 2, (3) the
> General instructions text block from section 3, exactly as written. Show me what you set.

### 5.4 Add SQL expressions  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/genie/02_sql_expressions.sql`. Each block is a SQL
> expression for this space's knowledge store: the comment line gives the type (FILTER, MEASURE or
> DIMENSION), the name, and a "use when the user says" description; the SQL below it is the
> expression. Add all of them to this space with those names and descriptions. Where a block is
> marked "(mv_task_kpis)" attach it to that table; otherwise attach to v_case_summary. List what
> you added.

### 5.5 Add value dictionaries  *(Genie Code prompt)*

> For the data assets in this space, add the following as the known values for these columns so
> you never guess literals: `<paste the Step 1.2 output for Case_stage, Task_Status, Role,
> Client_tier, Segment, Booking_Location>`. Also add Team values: Client Manager, CLM Ops,
> Channels. Mark Platinum (or the equivalent) as the highest-priority tier in its description.

### 5.6 Add example queries  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/genie/03_example_queries.sql`. Each `-- Q:` line is
> a user question and the SQL below it is the correct answer. Replace any literal values marked
> "confirm literal" (e.g. 'Singapore', 'Platinum') with the real values from the value dictionary
> you just added. Then add all pairs as Example SQL queries in this space.

### 5.7 Load benchmarks and run them  *(Genie Code prompt)*

> Open `/Workspace/Users/<you>/scb_onboarding/genie/04_benchmarks.json`. For every entry that has
> `expected_sql`, create a benchmark in this space with the question and that SQL as the expected
> answer, after replacing literals listed in `confirm_literals` with real values. For entries that
> only have `expected_behaviour`, add the question as a benchmark with no SQL and put the expected
> behaviour in the notes. Then run all benchmarks and give me the pass rate and the list of failures.

**What you should see:** a pass rate. Target is **≥ 90%**. For each failure:

> Benchmark `<id>` failed. Compare Genie's SQL with the expected SQL and tell me whether the fix
> belongs in (a) a metric view synonym or comment, (b) a value dictionary entry, (c) a SQL
> expression, or (d) an example query. Recommend the smallest change and apply it if it's (b),
> (c) or (d). If it's (a), give me the exact `ALTER VIEW` or YAML change to run in the SQL Editor.

Re-run benchmarks after each round of fixes. Stop when ≥ 90% and the remaining failures are
understood.

### 5.8 Replace the seed questions with the real ones  *(Genie Code prompt — when the business sends their list)*

> Here are the questions our users actually ask: `<paste the business owner's list>`. For each,
> write the correct SQL against the assets in this space, add it as a benchmark, and run it. Report
> pass rate and failures.

### 5.9 Share the space  *(UI)*

Space → **Share** → add the ops and management groups with **Can Run**; add two named owners with
**Can Edit**.

---

## Step 6 — Dashboard

### 6.1 Create the dashboard and add datasets  *(UI + Genie Code prompt)*

1. Left nav → **Dashboards** → **Create dashboard**. Name it `CIB Account Opening Control Tower`.
2. Open the **Data** tab. Click **+ Add data** → pick `<catalog>.<schema>.mv_onboarding_kpis`
   (it appears as a metric view). Rename the dataset to `kpi`. Repeat for `mv_task_kpis` → `task`.
3. Still in the Data tab, open Genie Code (✨) and paste:

> Open `/Workspace/Users/<you>/scb_onboarding/dashboard/02_datasets.sql`. It contains six named
> SQL datasets: cases, funnel, kpi_prev, reasons, journey, last_updated. Create each one as a
> dataset in this dashboard with that exact name, after replacing `scb_cib.account_opening` with
> `<catalog>.<schema>`. Create the dashboard parameters they use: `date_from` (date, default 30
> days ago), `date_to` (date, default today), `case_no` (string, default empty). Run each dataset
> once to confirm it returns rows.

### 6.2 Build the pages  *(Genie Code prompt — one per page)*

Switch to the **Canvas** tab, open Genie Code, and paste the following for **Page 1**:

> Open `/Workspace/Users/<you>/scb_onboarding/dashboard/01_dashboard_spec.md`. Build **Page 1 —
> Executive Summary** exactly as specified in that section: create the page, add every widget in
> the table using the dataset, type, measures and dimensions listed, apply the formatting from the
> "Formatting & conventions" section, and arrange them using the Layout line. Add the global
> filters from the "Global filters" section to the top of the page, bound to the `kpi` and `cases`
> datasets. When done, list the widgets you created.

Then repeat for Pages 2 through 6, changing only the page name in the prompt:

> Using the same spec file, build **Page 2 — Pipeline & Backlog** as specified, including global
> filters.

> … build **Page 3 — Turnaround Time** …  (fix the status filter to Completed as the spec says)

> … build **Page 4 — First Time Right** …  (if a Sankey widget is not available, use the heatmap
> table fallback the spec describes)

> … build **Page 5 — SLA** …

> … build **Page 6 — Case Explorer** … (bind widget 6.1 to the `case_no` parameter and widget 6.3
> to the `journey` dataset)

**What you should see after each page:** widgets rendering with numbers. If a widget is blank:

> Widget `<name>` on page `<n>` shows no data. Check which dataset and fields it uses, run the
> underlying query, and fix the binding or the query.

### 6.3 Connect Genie to the dashboard  *(UI)*

Dashboard → **⋮ → Settings** (or the Genie icon) → **Genie space** → choose
`CIB Account Opening Analytics` (the one you configured) rather than the auto-generated space.

### 6.4 Publish  *(UI)*

**Publish** → choose **Don't embed credentials** (so each viewer's row-level security applies)
→ Publish. Share with the same groups as the Genie space.

---

## Step 7 — Security (operational users see only their markets)

### 7.1 Fill the entitlement table  *(Genie Code prompt)*

> Insert rows into `<catalog>.<schema>.ref_user_entitlement`. Global users (see everything):
> `<list of user emails or group names>` with is_global = TRUE. Operational users:
> `<user or group → booking location pairs, e.g. sg-ops-team → Singapore>` with is_global = FALSE.
> Show me the table afterwards.

### 7.2 Attach the row filter  *(Genie Code prompt)*

> Attach the row filter function `<catalog>.<schema>.rf_booking_location` to the table
> `<catalog>.<schema>.<raw_table>` on its `Booking_Location` column so that every view built on it
> inherits the restriction. Then confirm by running `SELECT DISTINCT booking_location FROM
> <catalog>.<schema>.v_case_summary` and tell me what I, as the current user, can see.

**Test it:** ask an operational user to open the dashboard and confirm they see only their market.
Ask a global user to confirm they see all markets.

---

## Step 8 — UAT and go-live

### 8.1 UAT checklist (business owner, 1 hour)

| # | Test | Pass? |
|---|---|---|
| 1 | Page 1 total cases this month matches the existing manual report (± known exclusions) | |
| 2 | The 10 known cases from Step 2.4 show correct TAT / FTR / SLA flags in Case Explorer | |
| 3 | FTR rate on page 4 matches their current calculation on the same period | |
| 4 | A case initiated after 16:00 shows `sla_due_date` = next day and is **not** breached | |
| 5 | A case referred back to Request Initiator is **excluded** from the SLA population | |
| 6 | Operational user sees only their market; global user sees all | |
| 7 | Ask Genie the 5 sample questions — answers match the dashboard numbers | |
| 8 | Ask Genie "which RM has most breaches" — it says the data doesn't contain RM names | |

### 8.2 Go-live (UI)

- Set up the weekly review: one owner checks Genie's **Monitoring** tab for thumbs-down answers
  every Monday and re-runs benchmarks (Step 5.7 prompt) after any change.
- Record the version: in the SQL Editor, ask Genie Code
  > Show me the current definitions of mv_onboarding_kpis and mv_task_kpis and save them to
  > `/Workspace/Users/<you>/scb_onboarding/deployed/` with today's date in the filename.

---

## Appendix A — Changing the rules later

| Change | Where | Prompt |
|---|---|---|
| A market has a different cutoff | SQL Editor | "Update ref_market_cutoff: set cutoff_local_time to '15:00:00' for booking_location 'Hong Kong'." |
| New role appears | SQL Editor | "Add role '<name>' to ref_role_team mapped to team '<team>' with role_order <n> and sla_applicable <true/false>." |
| SLA should also apply to Channels | SQL Editor | "Set sla_applicable = TRUE for the Channels team in ref_role_team." |
| New synonym for a KPI | SQL Editor | "In the metric view mv_onboarding_kpis, add the synonym 'cycle time' to the measure avg_tat_hrs and recreate the view." |
| New Genie question keeps failing | Genie space → Genie Code | Use the Step 5.7 failure prompt |
| Dashboard too slow | SQL Editor | "Convert v_case_summary into a materialized view refreshed every 15 minutes, keeping the same name and columns." |

## Appendix B — Troubleshooting prompts

- **"Permission denied"** → "Tell me which privilege is missing for this statement and who can grant it."
- **Metric view won't create** → "Explain this error. If it's the YAML version, downgrade to 1.0 and remove synonyms; if it's a measure expression, show me which one and propose a fix."
- **Numbers don't match the old report** → "Compare the row count and completed-case count in v_case_summary for `<month>` against `<raw_table>` grouped by Case_stage, and list any cases present in one but not the other."
- **Genie gives a wrong answer** → "Show me the SQL you generated, explain which instruction or example you used, and tell me what context would have made you choose the right table or measure."

## Appendix C — Glossary

| Term | Meaning |
|---|---|
| Case | One client request to open one or more accounts |
| Task | One unit of work on a case by one role; a case has many tasks |
| Referral back | A queue returns the case to an earlier queue; creates a new task row with a Reason |
| FTR | First Time Right — Completed with zero referrals |
| TAT | Turnaround time — first task start to last task end, calendar hours, Completed only |
| SLA due date | Initiated date if before 16:00 local, else next day |
| Metric view | A governed KPI definition in Unity Catalog; dashboard and Genie both read it so numbers agree |
| Genie space | The natural-language question interface |
| Genie Code | The AI assistant that writes and runs code for you inside Databricks |
| Benchmark | A test question with a known correct answer, used to measure Genie's accuracy |
